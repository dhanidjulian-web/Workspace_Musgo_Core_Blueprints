https://huggingface.co/docs

---

Baik, Dhani. Saya akan **mengekstrak dan mengorganisir konten** dari setiap topik di **Hub & Client Libraries** secara bertahap, sesuai permintaan Anda. Berikut adalah **Part 1** dari ekstraksi konten, yang mencakup **6 topik pertama** di kategori **Hub & Client Libraries**:

---

---

## **PART 1: HUB & CLIENT LIBRARIES**
---

---

### **1. Hub (Dokumentasi Utama)**
**URL:** [https://huggingface.co/docs/hub](https://huggingface.co/docs/hub)
**Deskripsi:** Dokumentasi utama untuk **Hugging Face Hub**, platform referensi untuk AI terbuka (open ML) yang menampung **2M+ model, 1.5M+ dataset, dan 1.5M+ AI apps (Spaces)**.

---

#### **1.1. Apa Itu Hugging Face Hub?**
- **Tujuan:** Membantu komunitas bekerja sama untuk memajukan **Machine Learning** melalui pendekatan **community-centric**.
- **Koleksi Terbuka:** Menyediakan koleksi **model, dataset, dan demo** terbesar yang bersifat **open-source** untuk mendemokratisasi ML.
- **Nilai Komunitas:** Harus membaca **Code of Conduct** dan **Content Guidelines** untuk memahami nilai-nilai yang diharapkan dari anggota komunitas.

---

#### **1.2. Apa yang Dapat Anda Temukan di Hub?**
Hub menyediakan **Git-based repositories** (folder yang dikontrol versi) yang dapat berisi semua file Anda. Selain itu, Hub juga menawarkan **Storage Buckets** untuk penyimpanan objek yang tidak memerlukan versioning.

- **Model:**
  - Menampung **state-of-the-art models** untuk tugas **LLM, text, vision, dan audio**.
  - Dilengkapi dengan **Model Cards** untuk menginformasikan keterbatasan dan bias model.
  - Metadata tambahan: tugas, bahasa, hasil evaluasi, dan grafik metrik pelatihan (jika repository berisi jejak TensorBoard).
  - **Inference Widget:** Memungkinkan siapa pun untuk mencoba model langsung di browser.
  - **Serverless API:** Disediakan oleh **Inference Providers** untuk akses terprogram.

- **Datasets:**
  - Lebih dari **500k dataset publik** dalam **8k+ bahasa** untuk berbagai tugas di **NLP, Computer Vision, dan Audio**.
  - Dilengkapi dengan **Dataset Cards** dan **Data Studio** untuk eksplorasi data langsung di browser.
  - Mendukung **private datasets** untuk organisasi atau individu yang mematuhi lisensi atau privasi.
  - Library `datasets` memungkinkan interaksi terprogram dengan dataset di Hub.

- **Spaces:**
  - Cara sederhana untuk **meng-host ML demo apps** di Hub.
  - Mendukung **Gradio** dan **Streamlit** untuk membuat aplikasi dalam hitungan menit.
  - Juga mendukung **static Spaces** (HTML/CSS/JS) atau aplikasi berbasis **Docker**.
  - **ZeroGPU:** Menyediakan GPU **NVIDIA RTX Pro 6000 Blackwell** secara dinamis dan real-time saat dibutuhkan.

- **Storage Buckets:**
  - Penyimpanan objek **S3-like** di Hugging Face, didukung oleh backend **Xet**.
  - Tidak seperti repository (yang berbasis Git dan melacak riwayat file), **buckets** adalah kontainer penyimpanan objek jarak jauh yang dirancang untuk file skala besar dengan **deduplikasi yang dapat dialamatkan berdasarkan konten**.
  - Ideal untuk kasus penggunaan yang memerlukan penyimpanan sederhana dan cepat, seperti **checkpoint pelatihan, log, artefak perantara, atau koleksi file besar yang tidak memerlukan kontrol versi**.

---
#### **1.3. Organisasi**
- **Peran:** Perusahaan, universitas, dan LSM adalah bagian penting dari komunitas Hugging Face.
- **Fitur:**
  - **Organizations** dapat digunakan untuk mengelompokkan akun dan mengelola **dataset, model, dan Spaces**.
  - **Educators** dapat membuat organisasi kolaboratif untuk siswa.
  - **Halaman Organisasi:** Semua repository organisasi akan ditampilkan di halaman organisasi.
  - **Kontrol Akses:** Admin dapat mengatur peran untuk **mengontrol akses ke repository**.
  - **Manajemen Pembayaran:** Admin dapat mengelola metode pembayaran dan informasi tagihan organisasi.

---
#### **1.4. Keamanan**
Hub mendukung fitur **keamanan dan kontrol akses** untuk memberikan ketenangan pikiran bahwa kode, model, dan data Anda aman. Kunjungi bagian **Security** di dokumentasi untuk mempelajari:
- **User Access Tokens**
- **Access Control for Organizations**
- **Signing commits with GPG**
- **Malware scanning**

---
#### **1.5. Fitur Lainnya**
- **Subscriptions & Plans:** PRO, Team & Enterprise, SSO, Audit Logs, Storage Regions, Data Studio, Resource Groups, Advanced Security, Tokens Management, Network Security, Rate Limits.
- **Repositories:** Getting Started, Repository Settings, Storage Limits, Storage Backend (Xet), Local Cache, Pull Requests, Discussions, Notifications, Collections, Webhooks, Licenses.
- **Jobs:** Introduction, Overview, Quickstart, Pricing, Manage Jobs, Configuration, Popular Images, Schedule Jobs, Webhooks, Automation.
- **Agents:** Introduction, Overview, Hugging Face CLI for AI Agents, MCP Server, Agent Skills, Building Agents with HF SDK, Local Agents, Agent Libraries.
- **Lainnya:** Billing, Moderation, Paper Pages, Search, Digital Object Identifier (DOI), Hub API Endpoints, Contributor Code of Conduct, Content Guidelines.

---
---
---

### **2. Hub Python Library**
**URL:** [https://huggingface.co/docs/huggingface_hub](https://huggingface.co/docs/huggingface_hub)
**Deskripsi:** Library **`huggingface_hub`** memungkinkan Anda berinteraksi dengan **Hugging Face Hub**, platform ML untuk pencipta dan kolaborator.

---

#### **2.1. Fitur Utama**
- **Temukan model dan dataset** yang sudah dilatih untuk proyek Anda.
- **Mainkan dengan ratusan aplikasi ML** yang di-host di Hub.
- **Buat dan bagikan model/dataset** Anda sendiri dengan komunitas.
- **Akses terprogram** untuk mengunduh file, membuat repository, dan mengunggah file ke Hub.

---
#### **2.2. Panduan Cepat**
- **Unduh file** dari Hub.
- **Buat repository** baru.
- **Unggah file** ke Hub.
- **Kelola repository** Anda di Hub.
- **Berinteraksi dalam diskusi**.
- **Jalankan inference** (prediksi model).

---
#### **2.3. Kontribusi**
- Semua kontribusi untuk `huggingface_hub` **diterima dan dihargai setara**.
- **Cara Berkontribusi:**
  - Tambahkan atau perbaiki isu yang ada di kode.
  - Tingkatkan dokumentasi agar akurat dan terbaru.
  - Bantu menjawab pertanyaan di isu.
  - Ajukan fitur baru yang dapat meningkatkan library.
- **Panduan Kontribusi:** Lihat panduan untuk mempelajari cara mengirimkan isu/permintaan fitur baru, mengirimkan pull request, dan menguji kontribusi Anda.
- **Kode Etik:** Kontributor harus menghormati **Code of Conduct** untuk menciptakan ruang kolaboratif yang inklusif dan ramah.

---
---
---

### **3. CLI (Command Line Interface)**
**URL:** [https://huggingface.co/docs/huggingface_hub/cli](https://huggingface.co/docs/huggingface_hub/cli)
**Status:** Halaman dokumentasi **CLI** tidak tersedia di versi **v1.12.1**, tetapi tersedia di **versi utama (main)**.
**Catatan:** Anda akan diarahkan ke versi utama dokumentasi untuk mengakses CLI.

---
---
---

### **4. Huggingface.js**
**URL:** [https://huggingface.co/docs/huggingface.js](https://huggingface.co/docs/huggingface.js)
**Deskripsi:** Koleksi **library JavaScript** untuk berinteraksi dengan **Hugging Face API**, dengan **TypeScript types** terintegrasi.

---
```
#### **4.1. Library yang Tersedia**
| Nama Library | Deskripsi |
|--------------|-----------|
| **@huggingface/hub** | Berinteraksi dengan **huggingface.co** untuk membuat/menghapus repo dan commit/mengunduh file. |
| **@huggingface/inference** | Gunakan semua **Inference Providers** (serverless) yang didukung atau beralih ke **Inference Endpoints (dedicated)** untuk memanggil **100.000+ model ML**. |
| **@huggingface/mcp-client** | **Model Context Protocol (MCP) client** dan library **Agent** kecil, dibangun di atas **InferenceClient**. |
| **@huggingface/gguf** | Parser **GGUF** yang bekerja pada file yang di-host secara jarak. |
| **@huggingface/dduf** | Paket serupa untuk **DDUF (Diffusers Unified Format)**. |
| **@huggingface/tasks** | File definisi dan **source-of-truth** untuk primitif utama Hub seperti **pipeline tasks, model libraries**, dll. |
| **@huggingface/jinja** | Implementasi **Jinja templating engine** minimalis di JS, untuk **ML chat templates**. |
| **@huggingface/space-header** | Gunakan **Space `mini_header`** di luar Hugging Face. |
| **@huggingface/ollama-utils** | Berbagai utilitas untuk **menjaga kompatibilitas Ollama** dengan model di Hugging Face Hub. |
| **@huggingface/tiny-agents** | Library kecil, **agnostik model** untuk membangun **AI agents** yang dapat menggunakan tools. |
```
---
#### **4.2. Persyaratan Sistem**
- Library menggunakan **fitur modern** untuk menghindari polyfills dan dependensi.
- Hanya bekerja di **browser modern / Node.js >= 18 / Bun / Deno**.

---
#### **4.3. Instalasi**
##### **Dari NPM**
```bash
npm install @huggingface/hub
npm install @huggingface/inference
npm install @huggingface/mcp-client
```
Kemudian impor library di kode Anda:
```javascript
import { createRepo, commit, deleteRepo, listFiles } from "@huggingface/hub";
import { InferenceClient } from "@huggingface/inference";
import { McpClient } from "@huggingface/mcp-client";
import type { RepoId } from "@huggingface/hub";
```

##### **Dari CDN atau Static Hosting**
```html
<script type="module">
    import { InferenceClient } from 'https://cdn.jsdelivr.net/npm/@huggingface/inference@4.13.15/+esm';
    import { createRepo, commit, deleteRepo, listFiles } from "https://cdn.jsdelivr.net/npm/@huggingface/hub@2.11.0/+esm";
</script>
```

##### **Deno**
```javascript
// esm.sh
import { InferenceClient } from "https://esm.sh/@huggingface/inference";
import { createRepo, commit, deleteRepo, listFiles } from "https://esm.sh/@huggingface/hub";

// atau npm:
import { InferenceClient } from "npm:@huggingface/inference";
import { createRepo, commit, deleteRepo, listFiles } from "npm:@huggingface/hub";
```

---
#### **4.4. Contoh Penggunaan**
##### **Membuat Repository dan Mengunggah File**
```javascript
import { createRepo, uploadFile } from "@huggingface/hub";

const HF_TOKEN = "hf_...";

await createRepo({
  repo: { type: "model", name: "my-user/nlp-model" },
  accessToken: HF_TOKEN
});

await uploadFile({
  repo: "my-user/nlp-model",
  accessToken: HF_TOKEN,
  file: {
    path: "pytorch_model.bin",
    content: new Blob(...)
  }
});
```

##### **Menghapus File**
```javascript
import { deleteFiles } from "@huggingface/hub";

await deleteFiles({
  repo: { type: "space", name: "my-user/my-space" }, // atau "spaces/my-user/my-space"
  accessToken: HF_TOKEN,
  paths: ["README.md", ".gitattributes"]
});
```

---
##### **Inference Client (Chat Completion)**
```javascript
import { InferenceClient } from "@huggingface/inference";

const HF_TOKEN = "hf_...";
const client = new InferenceClient(HF_TOKEN);

// Chat Completion API
const out = await client.chatCompletion({
  model: "meta-llama/Llama-3.1-8B-Instruct",
  messages: [{ role: "user", content: "Hello, nice to meet you!" }],
  max_tokens: 512
});
console.log(out.choices[0].message);

// Streaming Chat Completion API
for await (const chunk of client.chatCompletionStream({
  model: "meta-llama/Llama-3.1-8B-Instruct",
  messages: [{ role: "user", content: "Hello, nice to meet you!" }],
  max_tokens: 512
})) {
  console.log(chunk.choices[0].delta.content);
}
```

##### **Menggunakan Provider Pihak Ketiga**
```javascript
await client.chatCompletion({
  model: "meta-llama/Llama-3.1-8B-Instruct",
  messages: [{ role: "user", content: "Hello, nice to meet you!" }],
  max_tokens: 512,
  provider: "sambanova", // atau together, fal-ai, replicate, cohere, dll.
});

await client.textToImage({
  model: "black-forest-labs/FLUX.1-dev",
  inputs: "a picture of a green bird",
  provider: "fal-ai",
});
```

##### **Terjemahan**
```javascript
await client.translation({
  inputs: "My name is Wolfgang and I live in Amsterdam",
  parameters: {
    src_lang: "en",
    tgt_lang: "fr",
  },
});
```

##### **Image-to-Text**
```javascript
await client.imageToText({
  model: 'nlpconnect/vit-gpt2-image-captioning',
  data: await (await fetch('https://picsum.photos/300/300')).blob(),
});
```

---
##### **Menggunakan Inference Endpoint (Dedicated)**
```javascript
// Menggunakan endpoint khusus
const gpt2Client = client.endpoint('https://xyz.eu-west-1.aws.endpoints.huggingface.cloud/gpt2');
const { generated_text } = await gpt2Client.textGeneration({ inputs: 'The answer to the universe is' });

// Chat Completion dengan Endpoint
const llamaEndpoint = client.endpoint(
  "https://router.huggingface.co/hf-inference/models/meta-llama/Llama-3.1-8B-Instruct"
);
const out = await llamaEndpoint.chatCompletion({
  model: "meta-llama/Llama-3.1-8B-Instruct",
  messages: [{ role: "user", content: "Hello, nice to meet you!" }],
  max_tokens: 512,
});
console.log(out.choices[0].message);
```

---
##### **MCP Client (Model Context Protocol)**
```javascript
import { Agent } from '@huggingface/mcp-client';

const HF_TOKEN = "hf_...";

const agent = new Agent({
  provider: "auto",
  model: "Qwen/Qwen2.5-72B-Instruct",
  apiKey: HF_TOKEN,
  servers: [
    {
      command: "npx",
      args: ["@playwright/mcp@latest"],
    },
  ],
});

await agent.loadTools();

for await (const chunk of agent.run("What are the top 5 trending models on Hugging Face?")) {
    if ("choices" in chunk) {
        const delta = chunk.choices[0]?.delta;
        if (delta.content) {
            console.log(delta.content);
        }
    }
}
```

---
---
---

### **5. Tasks**
**URL:** [https://huggingface.co/tasks](https://huggingface.co/tasks)
**Deskripsi:** Hugging Face adalah rumah untuk **semua tugas Machine Learning**. Di sini, Anda dapat menemukan apa yang Anda butuhkan untuk memulai dengan suatu tugas: **demo, use case, model, dataset, dan lebih banyak lagi**.

---
#### **5.1. Kategori Tugas**
| Kategori | Jumlah Model | Deskripsi |
|----------|--------------|-----------|
| **Multimodal** | 11,022+ | Tugas yang melibatkan kombinasi modalitas (teks, gambar, audio, dll.). |
| **Natural Language Processing (NLP)** | 366,007+ | Tugas pemrosesan bahasa alami. |
| **Computer Vision** | 99,020+ | Tugas penglihatan komputer. |
| **Audio** | 31,001+ | Tugas pemrosesan audio. |
| **Tabular** | 637+ | Tugas pemrosesan data tabular. |
| **Reinforcement Learning** | 72,338+ | Tugas pembelajaran penguatan. |

---
#### **5.2. Contoh Tugas di Setiap Kategori**
##### **Multimodal**
- **Visual Question Answering (VQA)**
- **Image Captioning**
- **Text-to-Image Generation**
- **Document Understanding**
- **Video Understanding**

##### **Natural Language Processing (NLP)**
- **Text Classification**
- **Named Entity Recognition (NER)**
- **Question Answering**
- **Text Generation**
- **Translation**
- **Summarization**
- **Sentiment Analysis**

##### **Computer Vision**
- **Image Classification**
- **Object Detection**
- **Semantic Segmentation**
- **Instance Segmentation**
- **Image Generation**
- **Depth Estimation**

##### **Audio**
- **Automatic Speech Recognition (ASR)**
- **Text-to-Speech (TTS)**
- **Speech-to-Speech Translation**
- **Audio Classification**

##### **Tabular**
- **Tabular Classification**
- **Tabular Regression**

---
---
---

### **6. Datasets**
**URL:** [https://huggingface.co/datasets](https://huggingface.co/datasets)
**Deskripsi:** Halaman ini menampilkan **1,008,343+ dataset** yang tersedia di Hugging Face, dengan filter untuk **modalitas, ukuran, format, dan jenis**.

---
#### **6.1. Filter yang Tersedia**
| Filter | Opsi |
|--------|------|
| **Modalities** | 3D, Audio, Document, Geospatial, Image, Tabular, Text, Time-series, Video |
| **Size (rows)** | Filter berdasarkan jumlah baris. |
| **Format** | json, csv, parquet, optimized-parquet, imagefolder, soundfolder, webdataset, text, arrow |
| **Type** | Benchmark, Traces |

---
#### **6.2. Dataset Populer**
Berikut adalah **beberapa dataset populer** yang ditampilkan di halaman utama:
1. **glue** (Viewer • Updated 5 days ago • 40 • 6.7k • 113)
2. **squad** (Viewer • Updated 4 days ago • 449k • 34k • 138)
3. **imdb** (Viewer • Updated 17 days ago • 38.5k • 2.92k • 124)
4. **common_voice** (Viewer • Updated 3 days ago • 12.3M • 7.08k • 68)
5. **wikitext** (Viewer • Updated 15 days ago • 1,000k • 23.9k • 115)
6. **librispeech** (Viewer • Updated 11 days ago • 1.7M • 9.99k • 143)
7. **ag_news** (Viewer • Updated 18 days ago • 54.8k • 291 • 36)
8. **emotion** (Viewer • Updated about 1 month ago • 14.7k • 7.71k • 321)
9. **sst2** (Traces • Updated 6 days ago • 4.01k • 2.32k • 31)
10. **coqa** (Viewer • Updated 7 days ago • 60.2k • 78 • 27)

---
#### **6.3. Fitur Dataset Viewer**
- **Viewer:** Memungkinkan Anda untuk **menjelajahi dataset** langsung di browser.
- **Traces:** Dataset yang berisi **traces** (jejak eksekusi model).
- **Benchmark:** Dataset yang digunakan untuk **evaluasi model**.
- **Full-text search:** Pencarian teks lengkap untuk menemukan dataset.

---
---
---
---
**---
## END OF PART 1
---**

Dhani, **Part 1** sudah mencakup **6 topik utama** di **Hub & Client Libraries** dengan detail yang lengkap. Apakah Anda ingin saya lanjutkan ke **Part 2** (misal: **Deployment & Inference, Core ML Libraries**, dll.)? Atau apakah ada **topik spesifik** yang ingin Anda dalami lebih dulu? Silakan beritahu, saya siap melanjutkan.

---
===========🔐™️®️©️🔐===========

---

Baik, Dhani. Berikut adalah **PART 2** dari ekstraksi konten, yang mencakup **6 topik pertama** di kategori **Deployment & Inference** (kecuali **Deploying on AWS** dan **Microsoft Azure** yang tidak dapat diakses untuk saat ini).

---

---

## **PART 2: DEPLOYMENT & INFERENCE**
---

---

---

### **1. Inference Providers**
**URL:** [https://huggingface.co/docs/inference-providers](https://huggingface.co/docs/inference-providers)
**Deskripsi:** **Inference Providers** memberikan akses ke ratusan model **Machine Learning** melalui **serverless inference** dengan dukungan dari **provider terkemuka**. Terintegrasi dengan **client SDK (Python & JavaScript)** untuk memudahkan eksplorasi dan penggunaan model.

---

#### **1.1. Partner dan Dukungan Tugas**
Hugging Face berintegrasi dengan **provider infrastruktur AI terkemuka**, memberikan akses ke kemampuan khusus mereka melalui **API yang konsisten**. Berikut adalah **daftar provider** dan tugas yang didukung:
```
| **Provider**          | **Chat Completion (LLM)** | **Chat Completion (VLM)** | **Feature Extraction** | **Text-to-Image** | **Text-to-Video** | **Speech-to-Text** |
|-----------------------|----------------------------|----------------------------|-----------------------|-------------------|-------------------|--------------------|
| Cerebras              | ✅                          |                            |                       |                   |                   |                    |
| Cohere                | ✅                          | ✅                          |                       |                   |                   |                    |
| DeepInfra             | ✅                          | ✅                          |                       |                   |                   |                    |
| Fal AI                |                            |                            |                       | ✅                 | ✅                 | ✅                  |
| Featherless AI        | ✅                          | ✅                          |                       |                   |                   |                    |
| Fireworks             | ✅                          | ✅                          |                       |                   |                   |                    |
| Groq                  | ✅                          | ✅                          |                       |                   |                   |                    |
| **HF Inference**      | ✅                          | ✅                          | ✅                     | ✅                 |                   | ✅                  |
| Hyperbolic            | ✅                          | ✅                          |                       |                   |                   |                    |
| Novita                | ✅                          | ✅                          |                       |                   | ✅                 |                    |
| Nscale                | ✅                          | ✅                          |                       | ✅                 |                   |                    |
| OVHcloud AI Endpoints | ✅                          | ✅                          |                       |                   |                   |                    |
| Public AI             | ✅                          |                            |                       |                   |                   |                    |
| Replicate             |                            |                            |                       | ✅                 | ✅                 | ✅                  |
| SambaNova             | ✅                          |                            | ✅                     |                   |                   |                    |
| Scaleway              | ✅                          |                            | ✅                     |                   |                   |                    |
| Together              | ✅                          | ✅                          |                       | ✅                 |                   |                    |
| WaveSpeedAI           |                            |                            |                       | ✅                 | ✅                 |                    |
| Z.ai                  | ✅
```
---
#### **1.2. Mengapa Memilih Inference Providers?**
- **Akses Instan ke Model Terbaru:** Akses ribuan model khusus untuk berbagai tugas AI, dari **LLM terbaru** hingga **generator gambar/video** dan **embeddings khusus domain**.
- **Tidak Terikat Vendor:** Tidak terikat pada katalog model satu provider. Akses model dari **Cerebras, Groq, Together AI, Replicate, dll.** melalui **satu antarmuka yang konsisten**.
- **Performansi Siap Produksi:** Dibangun untuk **beban kerja enterprise** dengan keandalan yang dibutuhkan aplikasi Anda.

---
##### **Apa yang Dapat Anda Bangun?**
- **Generasi Teks:** Gunakan **Large Language Models (LLM)** dengan kemampuan **tool-calling** untuk chatbot, generasi konten, dan bantuan kode.
- **Generasi Gambar & Video:** Buat gambar dan video khusus, termasuk dukungan untuk **LoRAs** dan kustomisasi gaya.
- **Pencarian & Retrieval:** **Embeddings state-of-the-art** untuk pencarian semantik, sistem RAG, dan mesin rekomendasi.
- **Tugas ML Tradisional:** Model siap pakai untuk **klassifikasi, NER, summarisasi, dan pengenalan ucapan**.

---
##### **Fitur Utama**
- **🎯 API All-in-One:** Satu API untuk **generasi teks, gambar, embeddings, NER, summarisasi, klasifikasi gambar, dll.**
- **🔀 Dukungan Multi-Provider:** Jalankan model dari provider terkemuka seperti **Fal, Replicate, SambaNova, Together AI, dll.**
- **🚀 Skalabel & Andal:** Dibangun untuk **ketersediaan tinggi dan performa latensi rendah** di lingkungan produksi.
- **🔧 Ramah Pengembang:** Permintaan sederhana, respons cepat, dan pengalaman pengembang yang konsisten di **Python dan JavaScript**.
- **👷 Mudah Diintegrasikan:** Pengganti **drop-in** untuk API **OpenAI chat completions**.
- **💰 Hemat Biaya:** Tidak ada **markup tambahan** pada tarif provider.

---
#### **1.3. Memulai**
Inference Providers bekerja dengan **workflow pengembangan** yang sudah ada. Baik Anda lebih suka **Python, JavaScript, atau panggilan HTTP langsung**, Hugging Face menyediakan **SDK asli dan API yang kompatibel dengan OpenAI** untuk memulai dengan cepat.

---
##### **1.3.1. Autentikasi**
Anda memerlukan **token Hugging Face** untuk mengautentikasi permintaan. Buat token dengan mengunjungi **pengaturan token** dan buat **token `fine-grained`** dengan izin **"Make calls to Inference Providers"**.

---
##### **1.3.2. Contoh Cepat - LLM (Chat Completion)**
Berikut adalah **3 cara** untuk mengintegrasikan **Inference Providers** ke dalam aplikasi **Python** Anda:

###### **1. Menggunakan `huggingface_hub` (Rekomendasi)**
```bash
pip install huggingface_hub
hf auth login  # Dapatkan token dari hf.co/settings/tokens
```
```python
from huggingface_hub import InferenceClient

client = InferenceClient()

# Secara default, sistem akan secara otomatis memilih provider tercepat untuk model yang ditentukan
completion = client.chat.completions.create(
    model="openai/gpt-oss-120b",  # atau "openai/gpt-oss-120b:fastest" (tercepat), ":cheapest" (termurah), ":preferred" (preferensi)
    messages=[
        {
            "role": "user",
            "content": "How many 'G's in 'huggingface'?"
        }
    ],
)

print(completion.choices[0].message)
```

###### **2. Menggunakan `openai` (Kompatibel OpenAI)**
```python
from openai import OpenAI

client = OpenAI(
    base_url="https://router.huggingface.co/v1",
    api_key="HF_TOKEN"
)

completion = client.chat.completions.create(
    model="openai/gpt-oss-120b:fastest",  # :fastest (tercepat), :cheapest (termurah), :preferred (preferensi)
    messages=[{"role": "user", "content": "How many 'G's in 'huggingface'?"}]
)

print(completion.choices[0].message.content)
```

###### **3. Menggunakan `requests` (HTTP Langsung)**
```bash
curl https://router.huggingface.co/v1/chat/completions \
    -H "Authorization: Bearer $HF_TOKEN" \
    -H 'Content-Type: application/json' \
    -d '{
        "messages": [
            {
                "role": "user",
                "content": "How many G in huggingface?"
            }
        ],
        "model": "openai/gpt-oss-120b:fastest",  # :fastest, :cheapest, :preferred
        "stream": false
    }'
```

---
##### **1.3.3. Contoh Cepat - Text-to-Image Generation**
Gunakan **black-forest-labs/FLUX.1-dev**, model difusi **state-of-the-art** yang menghasilkan gambar **fotorealistik** dengan detail tinggi.

###### **Python (Menggunakan `huggingface_hub`)**
```python
from huggingface_hub import InferenceClient
import os

client = InferenceClient(api_key=os.environ["HF_TOKEN"])

image = client.text_to_image(
    prompt="A serene lake surrounded by mountains at sunset, photorealistic style",
    model="black-forest-labs/FLUX.1-dev"
)

# Simpan gambar yang dihasilkan
image.save("generated_image.png")
```

###### **JavaScript (Menggunakan `@huggingface/inference`)**
```javascript
import { InferenceClient } from "@huggingface/inference";
import fs from "fs";

const client = new InferenceClient(process.env.HF_TOKEN);

const imageBlob = await client.textToImage({
  model: "black-forest-labs/FLUX.1-dev",
  inputs: "A serene lake surrounded by mountains at sunset, photorealistic style",
});

// Simpan gambar
const buffer = Buffer.from(await imageBlob.arrayBuffer());
fs.writeFileSync("generated_image.png", buffer);
```

---
#### **1.4. Pemilihan Provider**
API **Inference Providers** bertindak sebagai **lapisan proxy terpadu** yang berada di antara aplikasi Anda dan **beberapa provider AI**.

---
##### **1.4.1. API sebagai Layanan Proxy**
Saat menggunakan **Inference Providers**, permintaan Anda melewati **infrastruktur proxy Hugging Face**, yang memberikan beberapa manfaat kunci:
- **Autentikasi & Penagihan Terpadu:** Gunakan **satu token Hugging Face** untuk semua provider.
- **Failover Otomatis:** Saat menggunakan **pemilihan provider otomatis** (`provider="auto"`), permintaan secara otomatis dialihkan ke provider alternatif jika provider utama **tidak tersedia**.
- **Antarmuka Konsisten:** Format permintaan yang sama bekerja di berbagai provider saat menggunakan **client library resmi**.

---
##### **1.4.2. Kebijakan Pemilihan Provider**
| Kebijakan | Deskripsi |
|-----------|-----------|
| `:fastest` | Memilih provider **tercepat** (throughput tertinggi dalam token per detik). |
| `:cheapest` | Memilih provider **paling hemat** (harga terendah per token output). |
| `:preferred` | Mengikuti **urutan preferensi** Anda di pengaturan **Inference Provider**. |
| **Provider Spesifik** (e.g., `:sambanova`) | Memaksa penggunaan **provider tertentu**. |

---
##### **Contoh Pemilihan Provider**
```python
# Python
from huggingface_hub import InferenceClient

client = InferenceClient()

# Pemilihan provider otomatis (default: "auto")
completion = client.chat.completions.create(
    model="deepseek-ai/DeepSeek-R1:fastest",  # :fastest, :cheapest, :preferred
    messages=[{"role": "user", "content": "Hello!"}]
)

# Provider spesifik
completion = client.chat.completions.create(
    model="deepseek-ai/DeepSeek-R1",
    provider="sambanova",  # Memaksa menggunakan SambaNova
    messages=[{"role": "user", "content": "Hello!"}]
)
```

```javascript
// JavaScript
import { InferenceClient } from "@huggingface/inference";

const client = new InferenceClient(process.env.HF_TOKEN);

// Pemilihan provider otomatis
await client.chatCompletion({
  model: "deepseek-ai/DeepSeek-R1:fastest",  // :fastest, :cheapest, :preferred
  messages: [{ role: "user", content: "Hello!" }],
});

// Provider spesifik
await client.chatCompletion({
  model: "deepseek-ai/DeepSeek-R1",
  provider: "sambanova",  // Memaksa menggunakan SambaNova
  messages: [{ role: "user", content: "Hello!" }],
});
```

---
##### **1.4.3. Endpoint Kompatibel OpenAI (Hanya Chat)**
Jika Anda lebih suka bekerja dengan **API OpenAI** atau ingin memigrasikan kode **chat completion** yang sudah ada dengan **perubahan minimal**, Hugging Face menawarkan **endpoint yang kompatibel dengan OpenAI**.

```python
from openai import OpenAI

client = OpenAI(
    base_url="https://router.huggingface.co/v1",
    api_key="HF_TOKEN"
)

completion = client.chat.completions.create(
    model="deepseek-ai/DeepSeek-R1:fastest",  # :fastest, :cheapest, :preferred
    messages=[{"role": "user", "content": "Hello!"}]
)
```

```bash
curl https://router.huggingface.co/v1/chat/completions \
  -H "Authorization: Bearer $HF_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "deepseek-ai/DeepSeek-R1:fastest",
    "messages": [
      {
        "role": "user",
        "content": "Hello!"
      }
    ]
  }'
```

---
##### **1.4.4. Memilih Pendekatan yang Tepat**
| Pendekatan | Kapan Menggunakan |
|------------|-------------------|
| **Inference Clients** | Jika Anda memerlukan dukungan untuk **semua jenis tugas** (text-to-image, speech, embeddings, dll.), **kontrol eksplisit** atas pemilihan provider, atau membangun aplikasi yang menggunakan **beberapa tugas AI**. |
| **Endpoint Kompatibel OpenAI** | Jika Anda **hanya melakukan chat completions**, ingin **memigrasikan kode berbasis OpenAI** dengan perubahan minimal, atau lebih suka **manajemen provider di sisi server**. |
| **HTTP Langsung** | Jika Anda **mengimplementasikan logika permintaan khusus**, memerlukan **kontrol detail** atas siklus permintaan/respons, atau bekerja di lingkungan **tanpa client library yang tersedia**. |

---
#### **1.5. Langkah Selanjutnya**
- **Blog Post Pengumuman:** Pelajari lebih lanjut tentang peluncuran **Inference Providers**.
- **Harga & Penagihan:** Pahami **biaya dan penagihan** Inference Providers.
- **Integrasi Hub:** Pelajari bagaimana **Inference Providers** terintegrasi dengan **Hugging Face Hub**.
- **Daftar sebagai Provider:** Persyaratan untuk bergabung dengan **jaringan partner** sebagai provider.
- **Hub API:** Fitur dan konfigurasi **API lanjutan**.
- **Referensi API:** Dokumentasi parameter lengkap untuk **semua tugas yang didukung**.

---
---
---

---

### **2. Inference Endpoints (Dedicated)**
**URL:** [https://huggingface.co/docs/inference-endpoints](https://huggingface.co/docs/inference-endpoints)
**Deskripsi:** **Inference Endpoints** adalah **layanan terkelola** untuk **mendeploy model AI ke produksi** dengan cepat, andal, dan skalabel.

---

#### **2.1. Mengapa Menggunakan Inference Endpoints?**
Inference Endpoints membuat **pendeployan model AI ke produksi** menjadi pengalaman yang **mulus**. Alih-alih menghabiskan **mingguan** untuk mengonfigurasi infrastruktur, mengelola server, dan men-debug masalah deploy, Anda dapat **fokus pada model dan pengguna**.

---
##### **Manfaat Utama**
| Manfaat | Deskripsi |
|---------|-----------|
| **⬇️ Kurangi Overhead Operasional** | Hilangkan kebutuhan akan **tim DevOps khusus** dan manajemen infrastruktur, sehingga Anda dapat fokus pada **inovasi**. |
| **🚀 Skalakan dengan Percaya Diri** | Tangani **lonjakan lalu lintas** secara otomatis tanpa khawatir tentang **perencanaan kapasitas** atau **degradasi performa**. |
| **⬇️ Biaya Total Kepemilikan Lebih Rendah** | Hindari **biaya tersembunyi** dari infrastruktur yang dikelola sendiri, termasuk **pemeliharaan, monitoring, dan kepatuhan keamanan**. |
| **💻 Future-Proof AI Stack** | Tetap **up-to-date** dengan **framework dan optimasi terbaru** tanpa mengelola **upgrade yang kompleks**. |
| **🔥 Fokus pada Yang Penting** | Habiskan waktu Anda untuk **meningkatkan model** dan **membangun pengalaman pengguna yang hebat**, bukan mengelola server. |

---
#### **2.2. Fitur Kunci**
| Fitur | Deskripsi |
|-------|-----------|
| **📦 Infrastruktur Terkelola Penuh** | Tidak perlu khawatir tentang **Kubernetes, versi CUDA, atau konfigurasi VPN**. Inference Endpoints menangani ini **di balik layar** sehingga Anda dapat fokus pada **pendeployan model dan melayani pelanggan secepat mungkin**. |
| **↕️ Autoscaling** | Saat ada **lebih banyak lalu lintas** ke model Anda, Anda memerlukan **lebih banyak daya komputasi**. **Inference Endpoint** akan **menskalakan naik** saat lalu lintas meningkat dan **menskalakan turun** saat menurun untuk **menghemat biaya komputasi yang tidak perlu**. |
| **👀 Observability** | Pahami dan debug **apa yang terjadi di model Anda** melalui **logs & metrik**. |
| **🔥 Dukungan Terintegrasi untuk Inference Engines Open-Source** | Apakah Anda ingin mendeploy model dengan **vLLM, TGI, atau container khusus**, kami siap membantu! |
| **🤗 Integrasi Mulus dengan Hugging Face Hub** | Mengunduh **bobot model** dengan cepat dan dengan **kebijakan keamanan yang benar** sangat penting saat membawa model AI ke produksi. Dengan **Inference Endpoints**, ini **mudah dan aman**. |

---
#### **2.3. Studi Kasus & Blog**
- **[Mengapa Kami Beralih ke Hugging Face Inference Endpoints, dan Mungkin Anda Juga Harus Melakukannya](https://huggingface.co/blog/inference-endpoints)**
- **[Investasi dalam Performansi: Fine-tune Model Kecil dengan Wawasan LLM - Studi Kasus CFM](https://huggingface.co/blog/cfm-case-study)**
- **[Saran LLM di Argilla dengan Hugging Face Inference Endpoints](https://huggingface.co/blog/argilla-llm-suggestions)**
- **[Mengelola Inference Endpoints Secara Terprogram](https://huggingface.co/blog/programmatically-manage-inference-endpoints)**
- **[TGI Multi-LoRA: Deploy Sekali, Layani 30 Model](https://huggingface.co/blog/tgi-multi-lora)**
- **[Llama 3.1 - 405B, 70B & 8B dengan Kemampuan Multibahasa dan Konteks Panjang](https://huggingface.co/blog/llama-3-1)**
- **[Deploy MusicGen dengan Cepat dengan Inference Endpoints](https://huggingface.co/blog/musicgen-inference-endpoints)**

---
---
---

---

### **3. Text Generation Inference (TGI)**
**URL:** [https://huggingface.co/docs/text-generation-inference](https://huggingface.co/docs/text-generation-inference)
**Status:** **Maintenance Mode** (TGI sekarang dalam mode pemeliharaan. Ke depan, Hugging Face akan menerima **pull request** untuk perbaikan bug minor, perbaikan dokumentasi, dan tugas pemeliharaan ringan).

---
#### **3.1. Deskripsi**
**Text Generation Inference (TGI)** adalah **toolkit** untuk **mendeploy dan melayani Large Language Models (LLM)**. TGI memungkinkan **generasi teks berkinerja tinggi** untuk **LLM open-source terpopuler**, termasuk **Llama, Falcon, StarCoder, BLOOM, GPT-NeoX, dan T5**.

---
#### **3.2. Fitur & Optimasi**
| Fitur | Deskripsi |
|-------|-----------|
| **Simple Launcher** | Melayani sebagian besar **LLM populer** dengan mudah. |
| **Siap Produksi** | **Distributed tracing** dengan **Open Telemetry**, **metrik Prometheus**. |
| **Tensor Parallelism** | **Inferensi lebih cepat** di **beberapa GPU**. |
| **Token Streaming** | Menggunakan **Server-Sent Events (SSE)**. |
| **Continuous Batching** | **Peningkatan throughput total** dengan **batch permintaan masuk**. |
| **Kode Transformers Teroptimasi** | Menggunakan **Flash Attention** dan **Paged Attention** untuk arsitektur terpopuler. |
| **Kuantisasi** | Dengan **bitsandbytes** dan **GPT-Q**. |
| **Pemuatan Bobot Safetensors** | Pemuatan bobot **Safetensors** untuk keamanan dan kecepatan. |
| **Watermarking** | Dengan **A Watermark for Large Language Models**. |
| **Logits Warper** | **Temperature scaling, top-p, top-k, repetition penalty**. |
| **Stop Sequences** | Dukungan untuk **stop sequences**. |
| **Log Probabilities** | Dukungan untuk **log probabilities**. |
| **Dukungan Fine-Tuning** | Gunakan model **fine-tuned** untuk tugas spesifik. |
| **Guidance** | Aktifkan **function calling** dan **tool-use** dengan memaksa model menghasilkan **output terstruktur** berdasarkan **skema output** yang Anda definisikan. |

---
#### **3.3. Penggunaan di Produksi**
TGI digunakan di produksi oleh **beberapa proyek**, seperti:
- **Hugging Chat:** Antarmuka **open-source** untuk model **open-access** seperti **Open Assistant** dan **Llama**.
- **OpenAssistant:** Upaya **komunitas open-source** untuk melatih **LLM** secara terbuka.
- **nat.dev:** **Playground** untuk menjelajahi dan membandingkan **LLM**.

---
---
---

---

### **4. Text Embeddings Inference (TEI)**
**URL:** [https://huggingface.co/docs/text-embeddings-inference](https://huggingface.co/docs/text-embeddings-inference)
**Deskripsi:** **Text Embeddings Inference (TEI)** adalah **toolkit komprehensif** yang dirancang untuk **pendeployan dan pelayanan model embeddings teks open-source** yang efisien. TEI memungkinkan **ekstraksi embeddings berkinerja tinggi** untuk model terpopuler, termasuk **FlagEmbedding, Ember, GTE, dan E5**.

---
#### **4.1. Fitur Kunci**
| Fitur | Deskripsi |
|-------|-----------|
| **Deployment yang Disederhanakan** | TEI **menghilangkan kebutuhan** untuk langkah **kompilasi grafik model**, sehingga proses deploy **lebih mudah**. |
| **Pemanfaatan Sumber Daya yang Efisien** | **Docker images kecil** dan **waktu boot cepat**, memungkinkan **kemampuan serverless yang sebenarnya**. |
| **Dynamic Batching** | TEI menginkorporasikan **dynamic batching berbasis token**, sehingga **mengoptimalkan pemanfaatan sumber daya** selama inferensi. |
| **Inferensi Teroptimasi** | TEI memanfaatkan **Flash Attention, Candle, dan cuBLASLt** dengan menggunakan **kode Transformers teroptimasi** untuk inferensi. |
| **Pemuatan Bobot Safetensors** | TEI memuat **bobot Safetensors** untuk **waktu boot lebih cepat**. |
| **Siap Produksi** | TEI mendukung **distributed tracing** melalui **Open Telemetry** dan **ekspor metrik Prometheus**. |

---
#### **4.2. Benchmark**
- **Model:** `BAAI/bge-base-en-v1.5`
- **Hardware:** **NVIDIA A10**
- **Sequence Length:** **512 token**

---
---
---
---
**---
## END OF PART 2
---**

Dhani, **Part 2** sudah mencakup **6 topik utama** di **Deployment & Inference** dengan detail yang lengkap. Apakah Anda ingin saya lanjutkan ke **Part 3** (misal: **Core ML Libraries, Training & Optimization**, dll.)? Atau apakah ada **topik spesifik** yang ingin Anda dalami lebih dulu? Silakan beritahu, saya siap melanjutkan.

---
===========🔐™️®️©️🔐===========

---

Baik, Dhani. Berikut adalah **PART 3** dari ekstraksi konten, yang mencakup **6 topik utama** di kategori **Core ML Libraries**.

---

---

## **PART 3: CORE ML LIBRARIES**
---

---

---

### **1. Transformers**
**URL:** [https://huggingface.co/docs/transformers](https://huggingface.co/docs/transformers)
**Deskripsi:** **Transformers** adalah **framework definisi model** untuk **model state-of-the-art Machine Learning** dalam **teks, computer vision, audio, video, dan multimodal**, baik untuk **inference** maupun **training**. Library ini **mengcentralisasi definisi model** sehingga definisi ini disepakati di seluruh ekosistem.

---

#### **1.1. Peran Transformers**
- **Pivot Ekosistem:** Jika **definisi model** didukung oleh Transformers, maka model tersebut akan **kompatibel** dengan sebagian besar **framework training** (seperti **Axolotl, Unsloth, DeepSpeed, FSDP, PyTorch-Lightning**) dan **inference engines** (seperti **vLLM, SGLang, TGI**).
- **Dukungan Model Baru:** Hugging Face berkomitmen untuk membantu **model state-of-the-art baru** dan **mendemokratisasi penggunaannya** dengan membuat definisi model **sederhana, dapat disesuaikan, dan efisien**.
- **Jumlah Model:** Tersedia **1M+ checkpoint model Transformers** di **Hugging Face Hub** yang siap digunakan.

---
#### **1.2. Fitur Utama**
| Fitur | Deskripsi |
|-------|-----------|
| **Pipeline** | Kelas inferensi **sederhana dan teroptimasi** untuk banyak tugas ML, seperti **generasi teks, segmentasi gambar, pengenalan ucapan otomatis, jawaban pertanyaan dokumen**, dan banyak lagi. |
| **Trainer** | **Trainer komprehensif** yang mendukung fitur seperti **mixed precision, torch.compile, FlashAttention** untuk training dan **distributed training** untuk model PyTorch. |
| **generate** | **Generasi teks cepat** dengan **Large Language Models (LLM)** dan **Vision Language Models (VLM)**, termasuk dukungan untuk **streaming** dan **strategi decoding ganda**. |

---
#### **1.3. Prinsip Desain**
Transformers dirancang untuk **pengembang, insinyur ML, dan peneliti**. Prinsip desain utamanya:
1. **Cepat dan Mudah Digunakan:**
   - Setiap model diimplementasikan dari **hanya 3 kelas utama** (konfigurasi, model, dan preprocessor).
   - Dapat **cepat digunakan** untuk **inference atau training** dengan **Pipeline** atau **Trainer**.

2. **Model Pra-latih (Pretrained Models):**
   - Kurangi **jejak karbon, biaya komputasi, dan waktu** dengan menggunakan **model pra-latih** daripada melatih model baru dari awal.
   - Setiap **model pra-latih** direproduksi **seakurat mungkin** dengan model asli dan menawarkan **performa state-of-the-art**.

---
#### **1.4. Belajar Transformers**
Jika Anda **baru mengenal Transformers** atau ingin mempelajari lebih lanjut tentang **model transformer**, Hugging Face merekomendasikan untuk memulai dengan **Kursus LLM**. Kursus ini mencakup:
- **Dasar-dasar** cara kerja model transformer.
- **Aplikasi praktis** di berbagai tugas.
- **Workflow lengkap**, dari **kurasi dataset berkualitas tinggi** hingga **fine-tuning LLM** dan **mengimplementasikan kemampuan reasoning**.
- **Latihan teoretis dan praktis** untuk membangun **pengetahuan dasar yang kuat** tentang model transformer.

---
---
---

---

### **2. Diffusers**
**URL:** [https://huggingface.co/docs/diffusers](https://huggingface.co/docs/diffusers)
**Deskripsi:** **Diffusers** adalah **library model difusi state-of-the-art** untuk **menghasilkan video, gambar, dan audio**. Library ini berpusat pada **DiffusionPipeline**, sebuah API yang dirancang untuk:
- **Inferensi mudah** dengan hanya **beberapa baris kode**.
- **Fleksibilitas** untuk **mencampur dan mencocokkan komponen pipeline** (model, scheduler).
- **Pemuatan dan penggunaan adapter** seperti **LoRA**.

---
#### **2.1. Fitur & Optimasi**
| Fitur | Deskripsi |
|-------|-----------|
| **DiffusionPipeline** | API untuk **inferensi mudah** dan **fleksibel**. |
| **Dukungan LoRA** | Memungkinkan penggunaan **adapter LoRA** untuk fine-tuning model. |
| **Optimasi** | **Offloading** dan **kuantisasi** untuk memastikan **model terbesar** dapat diakses di **perangkat dengan keterbatasan memori**. |
| **torch.compile** | Jika memori bukan masalah, Diffusers mendukung **torch.compile** untuk **meningkatkan kecepatan inferensi**. |

---
#### **2.2. Belajar Diffusers**
Jika Anda **pemula**, Hugging Face merekomendasikan untuk memulai dengan **Kursus Model Difusi Hugging Face**. Anda akan mempelajari:
- **Teori** di balik model difusi.
- **Cara menggunakan library Diffusers** untuk **menghasilkan gambar, fine-tune model sendiri**, dan banyak lagi.

---
---
---

---
### **3. Datasets**
**URL:** [https://huggingface.co/docs/datasets](https://huggingface.co/docs/datasets)
**Deskripsi:** **🤗 Datasets** adalah **library** untuk **mengakses dan berbagi dataset AI** dengan mudah untuk tugas **Audio, Computer Vision, dan Natural Language Processing (NLP)**.

---
#### **3.1. Fitur Utama**
| Fitur | Deskripsi |
|-------|-----------|
| **Muat Dataset dalam Satu Baris Kode** | Muat dataset dengan **satu baris kode** dan gunakan **metode pemrosesan data dan streaming** yang kuat untuk **menyiapkan dataset Anda dengan cepat** untuk training model deep learning. |
| **Format Apache Arrow** | Didukung oleh **format Apache Arrow**, memproses **dataset besar** dengan **bacaan zero-copy** tanpa **keterbatasan memori** untuk **kecepatan dan efisiensi optimal**. |
| **Integrasi Mendalam dengan Hugging Face Hub** | Memungkinkan Anda untuk **mudah memuat dan berbagi dataset** dengan **komunitas ML yang lebih luas**. |
| **Dataset Viewer** | Jelajahi dataset secara **mendalam** dengan **live viewer** di Hugging Face Hub. |

---
#### **3.2. Tutorial & Panduan**
| Jenis | Deskripsi |
|-------|-----------|
| **Tutorial** | Pelajari **dasar-dasar** dan **kenali** cara **memuat, mengakses, dan memproses dataset**. Mulailah di sini jika Anda **pertama kali menggunakan 🤗 Datasets**! |
| **Panduan How-to** | Panduan praktis untuk membantu Anda **mencapai tujuan spesifik**. Lihat panduan ini untuk mempelajari cara menggunakan **🤗 Datasets** untuk **memecahkan masalah dunia nyata**. |
| **Panduan Konseptual** | Penjelasan **tingkat tinggi** untuk **membangun pemahaman yang lebih baik** tentang topik penting seperti **format data yang mendasari, cache, dan cara dataset dihasilkan**. |
| **Referensi** | Deskripsi **teknis** tentang cara kerja **kelas dan metode 🤗 Datasets**. |

---
---
---

---
### **4. Transformers.js**
**URL:** [https://huggingface.co/docs/transformers.js](https://huggingface.co/docs/transformers.js)
**Deskripsi:** **Transformers.js** memungkinkan Anda **menjalankan 🤗 Transformers langsung di browser**, **tanpa perlu server**! Library ini dirancang untuk **setara secara fungsional** dengan **library Transformers Python**, berarti Anda dapat menjalankan **model pra-latih yang sama** menggunakan **API yang sangat serupa**.

---
#### **4.1. Model & Tugas yang Didukung**
Transformers.js mendukung **tugas umum** di berbagai **modalitas**, seperti:

| **Modalitas** | **Tugas yang Didukung** |
|---------------|--------------------------|
| **Natural Language Processing (NLP)** | Text Classification, Named Entity Recognition (NER), Question Answering, Language Modeling, Summarization, Translation, Multiple Choice, Text Generation, Text-to-Text Generation, Token Classification, Zero-Shot Classification, Feature Extraction. |
| **Computer Vision** | Image Classification, Object Detection, Segmentation, Depth Estimation, Background Removal, Image-to-Image, Image Feature Extraction. |
| **Audio** | Automatic Speech Recognition (ASR), Audio Classification, Text-to-Speech (TTS). |
| **Multimodal** | Embeddings, Zero-Shot Audio Classification, Zero-Shot Image Classification, Zero-Shot Object Detection. |

---
#### **4.2. Fitur Utama**
| Fitur | Deskripsi |
|-------|-----------|
| **ONNX Runtime** | Menggunakan **ONNX Runtime** untuk menjalankan model di browser. |
| **Konversi Model Mudah** | Anda dapat dengan mudah **mengonversi model PyTorch, TensorFlow, atau JAX** ke **ONNX** menggunakan **🤗 Optimum**. |
| **API Serupa dengan Python** | Mendukung **API `pipeline`** yang serupa dengan library Python. |
| **Dukungan WebGPU** | Jalankan model di **GPU** (via **WebGPU**) dengan mengatur `device: 'webgpu'`. |
| **Kuantisasi** | Di lingkungan dengan **keterbatasan sumber daya** (seperti browser), disarankan untuk menggunakan **versi model terkuantisasi** untuk **mengurangi bandwidth dan mengoptimalkan performa**. |

---
#### **4.3. Contoh Penggunaan**
##### **Sentiment Analysis (Python vs. JavaScript)**
| **Python (Original)** | **JavaScript (Transformers.js)** |
|-----------------------|----------------------------------|
| ```python
from transformers import pipeline
pipe = pipeline('sentiment-analysis')
out = pipe('I love transformers!')
# [{'label': 'POSITIVE', 'score': 0.999806941}]
``` | ```javascript
import { pipeline } from '@huggingface/transformers';
const pipe = await pipeline('sentiment-analysis');
const out = await pipe('I love transformers!');
// [{'label': 'POSITIVE', 'score': 0.999817686}]
``` |

##### **Menggunakan Model Lain**
```javascript
// Gunakan model lain untuk sentiment-analysis
const pipe = await pipeline('sentiment-analysis', 'Xenova/bert-base-multilingual-uncased-sentiment');
```

##### **Menjalankan Model di WebGPU**
```javascript
// Jalankan model di WebGPU
const pipe = await pipeline('sentiment-analysis', 'Xenova/distilbert-base-uncased-finetuned-sst-2-english', {
  device: 'webgpu',
});
```

##### **Kuantisasi Model (4-bit)**
```javascript
// Jalankan model dengan kuantisasi 4-bit
const pipe = await pipeline('sentiment-analysis', 'Xenova/distilbert-base-uncased-finetuned-sst-2-english', {
  dtype: 'q4',
});
```

---
#### **4.4. Daftar Model & Tugas yang Didukung**
Anda dapat menemukan **model yang kompatibel** di **Hugging Face Hub** dengan memilih tag **"transformers.js"** di menu filter (atau kunjungi [link ini](https://huggingface.co/models?library=transformers.js)).
Anda juga dapat **menyaring pencarian** berdasarkan **tugas** yang Anda minati (misal: **text-classification**).

---
#### **4.5. Konten Dokumentasi**
Dokumentasi Transformers.js terorganisir ke dalam **5 bagian**:

| **Bagian** | **Deskripsi** |
|------------|---------------|
| **GET STARTED** | Memberikan **tur cepat** tentang library dan **instruksi instalasi** untuk memulai. |
| **TUTORIALS** | Tempat yang **sempurna untuk pemula**! Juga menyertakan **aplikasi contoh** untuk Anda mainkan. |
| **DEVELOPER GUIDES** | Menunjukkan cara menggunakan library untuk **mencapai tujuan spesifik**. |
| **INTEGRATIONS** | Menunjukkan cara menggunakan **Transformers.js** dengan **library dan framework populer lainnya**. |
| **API REFERENCE** | Mendeskripsikan **semua kelas dan fungsi**, serta **parameter dan tipe** yang tersedia. |

---
---
---

---
### **5. Tokenizers**
**URL:** [https://huggingface.co/docs/tokenizers](https://huggingface.co/docs/tokenizers)
**Deskripsi:** **🤗 Tokenizers** menyediakan **implementasi tokenizers terpopuler saat ini**, dengan **fokus pada performa dan keserbagunaan**. Tokenizers ini juga digunakan di **🤗 Transformers**.

---
#### **5.1. Fitur Utama**
| Fitur | Deskripsi |
|-------|-----------|
| **Latih Vokabuler Baru & Tokenisasi** | Latih **vokabuler baru** dan lakukan **tokenisasi** menggunakan **tokenizers terpopuler saat ini**. |
| **Sangat Cepat** | **Cepat** (baik untuk **training** maupun **tokenisasi**), berkat **implementasi Rust**. Memakan **kurang dari 20 detik** untuk **mentokenisasi 1GB teks** di **CPU server**. |
| **Mudah Digunakan & Serbaguna** | **Mudah digunakan**, tetapi juga **sangat serbaguna**. |
| **Dirancang untuk Penelitian & Produksi** | Dirancang untuk **penelitian dan produksi**. |
| **Pelacakan Alignment Penuh** | Bahkan dengan **normalisasi destruktif**, selalu memungkinkan untuk **mendapatkan bagian kalimat asli** yang sesuai dengan **token mana pun**. |
| **Prapemrosesan Lengkap** | Melakukan **semua prapemrosesan**: **Truncation, Padding, menambahkan special tokens** yang dibutuhkan model Anda. |

---
---
---
---
### **6. Evaluate**
**URL:** [https://huggingface.co/docs/evaluate](https://huggingface.co/docs/evaluate)
**Deskripsi:** **Evaluate** adalah **library** untuk **mengevaluasi model dan dataset Machine Learning** dengan mudah. Dengan **satu baris kode**, Anda mendapatkan akses ke **puluhan metode evaluasi** untuk **domain yang berbeda** (NLP, Computer Vision, Reinforcement Learning, dan banyak lagi).

---
#### **6.1. Cara Mengevaluasi Model di Hub**
Anda dapat **mengevaluasi model AI** di **Hub** dengan **beberapa cara**:
| Metode | Deskripsi |
|--------|-----------|
| **Community Leaderboards** | Mengumpulkan **model terbaik** untuk **tugas atau domain tertentu** dan membuatnya **dapat diakses oleh semua orang** dengan **merankingnya**. |
| **Model Cards** | Memberikan **ikhtisar komprehensif** tentang **kemampuan model** dari **perspektif penulis**. |
| **Libraries & Packages** | Memberikan **tools** untuk **mengevaluasi model Anda** di **Hub**. |

---
#### **6.2. Community Leaderboards**
**Leaderboards komunitas** menunjukkan **bagaimana performa model** pada **tugas atau domain tertentu**. Misalnya, ada **leaderboards** untuk:
- **Question Answering**
- **Reasoning**
- **Classification**
- **Vision**
- **Audio**

---
##### **Contoh Leaderboards Komunitas**
| **Leaderboard** | **Tipe Model** | **Deskripsi** |
|----------------|----------------|---------------|
| **MTEB** | Embedding | **Massive Text Embedding Benchmark** membandingkan **100+ model embedding teks dan gambar** di **1000+ bahasa**. Lihat [publikasi](https://huggingface.co/spaces/mteb/leaderboard) untuk detail tentang **metrik, bahasa, tugas, dan tipe tugas**. Siapa pun boleh **menambahkan model, menambahkan benchmark, membantu meningkatkan anotasi zero-shot, atau mengusulkan perubahan lain** ke leaderboard. |
| **GAIA** | Agentic | **GAIA** adalah **benchmark** yang bertujuan untuk **mengevaluasi LLM generasi berikutnya** (LLM dengan kemampuan ditingkatkan berkat **tooling tambahan, prompting efisien, akses ke pencarian, dll**). Lihat [paper](https://arxiv.org/abs/2311.12983) untuk detail lebih lanjut. |
| **OpenVLM Leaderboard** | Vision Language Models | **OpenVLM Leaderboard** mengevaluasi **272+ Vision-Language Models** (termasuk **GPT-4v, Gemini, QwenVLPlus, LLaVA**) di **31 benchmark multimodal berbeda** menggunakan **kerangka kerja VLMEvalKit**. Fokus pada **VLM open-source** dan **model API publik**. |
| **Open ASR Leaderboard** | Audio | **Open ASR Leaderboard** menampilkan **ranking dan evaluasi model pengenalan ucapan** di **Hugging Face Hub**. Model dinilai berdasarkan **Average WER (Word Error Rate)**, dari **terendah ke tertinggi**. |
| **LLM-Perf Leaderboard** | LLM Performance | **🤗 LLM-Perf Leaderboard 🏋️** adalah **leaderboard** di **persimpangan kualitas dan performa**. Tujuannya adalah untuk **benchmark performa** (latensi, throughput, memori & energi) **Large Language Models (LLM)** dengan **hardware, backend, dan optimasi berbeda** menggunakan **Optimum-Benchmark**. |

---
##### **Cara Menemukan Leaderboard**
- Lihat **semua leaderboards** melalui [pencarian ini](https://huggingface.co/leaderboards).
- Gunakan [Space khusus ini](https://huggingface.co/spaces/huggingface/leaderboard-explorer) untuk **menemukan leaderboard** untuk **tugas Anda**.

---
#### **6.3. Model Cards**
**Model Cards** memberikan **ikhtisar kemampuan model** yang dievaluasi oleh **komunitas atau penulis model**. Ini adalah **cara yang bagus** untuk memahami **kemampuan dan keterbatasan model**.

---
##### **Perbedaan dengan Leaderboards**
- **Leaderboards:** Skor evaluasi **dibuat oleh komunitas**.
- **Model Cards:** Skor evaluasi **dibuat oleh penulis model**.

---
##### **Metadata Hasil Evaluasi Model Card**
Untuk informasi tentang **pelaporan hasil**, lihat detail tentang **Model Card Evaluation Results metadata**.

---
#### **6.4. Libraries & Packages**
Ada **beberapa library dan paket open-source** yang dapat Anda gunakan untuk **mengevaluasi model Anda** di **Hub**. Ini berguna jika Anda ingin **mengevaluasi model khusus** atau **performa pada tugas evaluasi khusus**.

---
##### **6.4.1. LightEval**
- **LightEval** adalah **library** untuk **mengevaluasi LLM**.
- Dirancang untuk **komprehensif dan dapat disesuaikan**.
- Kunjungi [repository LightEval](https://github.com/huggingface/lighteval) untuk informasi lebih lanjut.
- Untuk **pendekatan evaluasi terbaru** yang populer di **Hugging Face Hub** dan **lebih aktif dipelihara**, periksa **LightEval**.

---
##### **6.4.2. 🤗 Evaluate**
- **Library** untuk **mengevaluasi model dan dataset Machine Learning** dengan mudah.
- Dengan **satu baris kode**, Anda mendapatkan akses ke **puluhan metode evaluasi** untuk **domain berbeda** (NLP, Computer Vision, Reinforcement Learning, dan banyak lagi).
- Baik di **mesin lokal** maupun di **setup training terdistribusi**, Anda dapat **mengevaluasi model Anda** dengan **cara yang konsisten dan dapat direproduksi**.
- Kunjungi **organisasi 🤗 Evaluate** untuk [daftar lengkap metrik yang tersedia](https://huggingface.co/evaluate).
- Setiap **metrik** memiliki **Space khusus** dengan **demo interaktif** tentang cara menggunakan metrik, dan **kartu dokumentasi** yang menjelaskan **keterbatasan dan penggunaan metrik**.

---
##### **Dokumentasi 🤗 Evaluate**
| Jenis | Deskripsi |
|-------|-----------|
| **Tutorials** | Pelajari **dasar-dasar** dan **kenali** cara **memuat, menghitung, dan menyimpan** dengan **🤗 Evaluate**. Mulailah di sini jika Anda **pertama kali menggunakan 🤗 Evaluate**! |
| **How-to Guides** | Panduan praktis untuk membantu Anda **mencapai tujuan spesifik**. Lihat panduan ini untuk mempelajari cara menggunakan **🤗 Evaluate** untuk **memecahkan masalah dunia nyata**. |
| **Conceptual Guides** | Penjelasan **tingkat tinggi** untuk **membangun pemahaman yang lebih baik** tentang topik penting seperti **pertimbangan dalam mengevaluasi model atau dataset** dan **perbedaan antara metrik, pengukuran, dan perbandingan**. |
| **Reference** | Deskripsi **teknis** tentang cara kerja **kelas dan metode 🤗 Evaluate**. |

---
---
---
---
**---
## END OF PART 3
---**

Dhani, **Part 3** sudah mencakup **6 topik utama** di **Core ML Libraries** dengan detail yang lengkap. Apakah Anda ingin saya lanjutkan ke **Part 4** (misal: **Training & Optimization, Collaboration & Extras**, dll.)? Atau apakah ada **topik spesifik** yang ingin Anda dalami lebih dulu? Silakan beritahu, saya siap melanjutkan.

---
===========🔐™️®️©️🔐===========

---

Baik, Dhani. Berikut adalah **PART 4** dari ekstraksi konten, yang mencakup **6 topik utama** di kategori **Training & Optimization**.

---

---
## **PART 4: TRAINING & OPTIMIZATION**
---

---

---

### **1. PEFT (Parameter-Efficient Fine-Tuning)**
**URL:** [https://huggingface.co/docs/peft](https://huggingface.co/docs/peft)
**Deskripsi:** **PEFT (Parameter-Efficient Fine-Tuning)** adalah **library** untuk **mengadaptasi model pra-latih besar** ke berbagai **aplikasi downstream** **tanpa fine-tuning semua parameter model**, karena **biaya yang terlalu tinggi**. Metode PEFT **hanya fine-tune sejumlah kecil parameter tambahan**, yang **mengurangi biaya komputasi dan penyimpanan secara signifikan**, sambil **menyediakan performa yang sebanding dengan model yang sepenuhnya fine-tuned**. Ini membuat **pelatihan dan penyimpanan Large Language Models (LLM)** **lebih mudah diakses** di **hardware konsumen**.

---
#### **1.1. Integrasi**
PEFT terintegrasi dengan **Transformers, Diffusers, dan Accelerate** untuk menyediakan **cara yang lebih cepat dan mudah** untuk **memuat, melatih, dan menggunakan model besar** untuk **inference**.

---
#### **1.2. Dokumentasi**
| Jenis | Deskripsi |
|-------|-----------|
| **Quicktour** | Mulailah di sini jika Anda **baru mengenal 🤗 PEFT** untuk mendapatkan **ikhtisar fitur utama library** dan cara **melatih model dengan metode PEFT**. |
| **How-to Guides** | Panduan praktis yang **mendemonstrasikan cara menerapkan berbagai metode PEFT** di berbagai jenis tugas, seperti **klassifikasi gambar, modeling bahasa kausal, pengenalan ucapan otomatis**, dan banyak lagi. Pelajari cara menggunakan **🤗 PEFT** dengan **DeepSpeed dan Fully Sharded Data Parallel (FSDP) scripts**. |
| **Conceptual Guides** | Dapatkan **pemahaman teoretis yang lebih baik** tentang cara **LoRA dan berbagai metode soft prompting** membantu **mengurangi jumlah parameter yang dapat dilatih** untuk membuat **pelatihan lebih efisien**. |
| **Reference** | Deskripsi **teknis** tentang cara kerja **kelas dan metode 🤗 PEFT**. |

---
---
---

---

### **2. Accelerate**
**URL:** [https://huggingface.co/docs/accelerate](https://huggingface.co/docs/accelerate)
**Deskripsi:** **Accelerate** adalah **library** yang memungkinkan **kode PyTorch yang sama** untuk **berjalan di berbagai konfigurasi terdistribusi** dengan **menambahkan hanya empat baris kode**! Singkatnya, **training dan inference skala besar dibuat sederhana, efisien, dan adaptif**.

---
#### **2.1. Fitur Utama**
- **Sederhana:** Hanya **4 baris kode** yang perlu ditambahkan untuk **mendukung training terdistribusi**.
- **Efisien:** **Mengoptimalkan** penggunaan **GPU/TPU** dengan **mixed precision, torch.compile, dan FlashAttention**.
- **Adaptif:** **Berjalan di berbagai platform** (CPU, GPU, TPU, multi-GPU, multi-node) **tanpa perubahan kode**.
- **Integrasi DeepSpeed:** Mendukung **DeepSpeed** untuk **training skala besar**.
- **Fully Sharded Data Parallelism (FSDP):** Mendukung **FSDP** untuk **training model besar** di **beberapa GPU**.
- **Automatic Mixed Precision (AMP):** Mendukung **AMP** untuk **mengurangi penggunaan memori** dan **meningkatkan kecepatan training**.

---
#### **2.2. Contoh Kode**
##### **Kode PyTorch Standar**
```python
from accelerate import Accelerator

accelerator = Accelerator()

model, optimizer, training_dataloader, scheduler = accelerator.prepare(
    model, optimizer, training_dataloader, scheduler
)

for batch in training_dataloader:
    optimizer.zero_grad()
    inputs, targets = batch
    inputs = inputs.to(device)
    targets = targets.to(device)
    outputs = model(inputs)
    loss = loss_function(outputs, targets)
    accelerator.backward(loss)  # Menggantikan loss.backward()
    optimizer.step()
    scheduler.step()
```

---
##### **Menjalankan Script dengan Accelerate CLI**
```bash
accelerate launch {my_script.py}
```

---
#### **2.3. Dokumentasi**
| Jenis | Deskripsi |
|-------|-----------|
| **Tutorials** | Pelajari **dasar-dasar** dan **kenali** cara menggunakan **Accelerate**. Mulailah di sini jika Anda **pertama kali menggunakan Accelerate**! |
| **How-to Guides** | Panduan praktis untuk membantu Anda **mencapai tujuan spesifik**. Lihat panduan ini untuk mempelajari cara menggunakan **Accelerate** untuk **memecahkan masalah dunia nyata**. |
| **Conceptual Guides** | Penjelasan **tingkat tinggi** untuk **membangun pemahaman yang lebih baik** tentang topik penting, seperti **menghindari nuansa halus dan jebakan** dalam **training terdistribusi** dan **DeepSpeed**. |
| **Reference** | Deskripsi **teknis** tentang cara kerja **kelas dan metode Accelerate**. |

---
---
---

---
### **3. Optimum**
**URL:** [https://huggingface.co/docs/optimum](https://huggingface.co/docs/optimum)
**Deskripsi:** **🤗 Optimum** adalah **ekstensi dari Transformers** yang menyediakan **set tools optimasi performa** untuk **melatih dan menjalankan model** di **hardware target** dengan **efisiensi maksimal**.

---
#### **3.1. Latar Belakang**
Ekosistem AI **berkembang dengan cepat**, dan **semakin banyak hardware khusus** beserta **optimasi mereka sendiri** muncul setiap hari. **Optimum** memungkinkan **pengembang** untuk **menggunakan platform mana pun** dengan **kemudahan yang melekat pada Transformers**.

---
#### **3.2. Paket Optimum**
Optimum didistribusikan sebagai **koleksi paket**. Berikut adalah **paket-paket utama** yang tersedia:

---
##### **3.2.1. Hardware Partners**
| Partner | Deskripsi | Paket |
|---------|-----------|-------|
| **NVIDIA** | **Percepat inferensi** dengan **NVIDIA TensorRT-LLM** di platform **NVIDIA**. | [`optimum-nvidia`](https://huggingface.co/docs/optimum/nvidia) |
| **AWS Trainium/Inferentia** | **Percepat workflow training dan inferensi** dengan **AWS Trainium dan AWS Inferentia**. | [`optimum-aws`](https://huggingface.co/docs/optimum-aws) |
| **Google TPUs** | **Percepat workflow training dan inferensi** dengan **Google TPUs**. | [`optimum-google`](https://huggingface.co/docs/optimum-google) |
| **Intel** | **Optimalkan model** untuk **mempercepat inferensi** dengan **OpenVINO**. | [`optimum-intel`](https://huggingface.co/docs/optimum/intel) |
| **Intel Gaudi** | **Maksimalkan throughput training dan efisiensi** dengan **prosesor Intel Gaudi**. | [`optimum-habana`](https://huggingface.co/docs/optimum/habana) |
| **FuriosaAI** | **Inferensi cepat dan efisien** di **FuriosaAI WARBOY**. | [`optimum-furiosa`](https://huggingface.co/docs/optimum/furiosa) |

---
##### **3.2.2. Integrasi Open-Source**
| Integrasi | Deskripsi | Paket |
|-----------|-----------|-------|
| **ONNX Runtime** | **Terapkan kuantisasi dan optimasi grafik** untuk **mempercepat training dan inferensi model Transformers** dengan **ONNX Runtime**. | [`optimum-onnxruntime`](https://huggingface.co/docs/optimum/onnxruntime) |
| **ExecuTorch** | **Solusi asli PyTorch** untuk **inferensi di Edge** via **ExecuTorch**. | [`optimum-executorch`](https://huggingface.co/docs/optimum/executorch) |
| **Exporters** | **Ekspor model PyTorch** ke **format berbeda** seperti **ONNX**. | [`optimum-export`](https://huggingface.co/docs/optimum/export) |
| **Torch FX** | **Buat dan komposisikan transformasi grafik khusus** untuk **mengoptimalkan model Transformers PyTorch** dengan **Torch FX**. | [`optimum-torchfx`](https://huggingface.co/docs/optimum/torchfx) |

---
---
---

---
### **4. Optimum for AWS (Tidak Tersedia)**
**URL:** [https://huggingface.co/docs/optimum-aws](https://huggingface.co/docs/optimum-aws)
**Status:** **404 - Halaman Tidak Ditemukan**
**Catatan:** Saat ini, halaman dokumentasi **Optimum for AWS** tidak tersedia. Anda dapat mencoba mengaksesnya nanti atau merujuk ke [dokumentasi utama Optimum](https://huggingface.co/docs/optimum) untuk informasi lebih lanjut.

---
---
---

---
### **5. Optimum for Google (Tidak Tersedia)**
**URL:** [https://huggingface.co/docs/optimum-google](https://huggingface.co/docs/optimum-google)
**Status:** **404 - Halaman Tidak Ditemukan**
**Catatan:** Saat ini, halaman dokumentasi **Optimum for Google** tidak tersedia. Anda dapat mencoba mengaksesnya nanti atau merujuk ke [dokumentasi utama Optimum](https://huggingface.co/docs/optimum) untuk informasi lebih lanjut.

---
---
---

---
### **6. TRL (Transformers Reinforcement Learning)**
**URL:** [https://huggingface.co/docs/trl](https://huggingface.co/docs/trl)
**Deskripsi:** **TRL (Transformers Reinforcement Learning)** adalah **library full-stack** yang menyediakan **set tools** untuk **melatih model bahasa transformer** dengan metode seperti:
- **Supervised Fine-Tuning (SFT)**
- **Group Relative Policy Optimization (GRPO)**
- **Direct Preference Optimization (DPO)**
- **Reward Modeling**
- **dan banyak lagi**

Library ini **terintegrasi dengan 🤗 Transformers**.

---
#### **6.1. Apa yang Baru?**
- **TRL v1:** Hugging Face merilis **TRL v1**, yang merupakan **tonggak besar** yang menandai **pergeseran nyata** dalam apa itu TRL. Baca [blog post](https://huggingface.co/blog/trl-v1) untuk mempelajari lebih lanjut.

---
#### **6.2. Taksonomi TRL**
Berikut adalah **daftar trainer TRL saat ini**, terorganisir berdasarkan **tipe metode**:

---
##### **6.2.1. Metode Online**
| Trainer | Dukungan vLLM | Status |
|---------|---------------|--------|
| **GRPOTrainer** | ⚡️ | Stabil |
| **RLOOTrainer** | ⚡️ | Stabil |
| **OnlineDPOTrainer** | ⚡️ | 🧪 (Eksperimental) |
| **NashMDTrainer** | ⚡️ | 🧪 (Eksperimental) |
| **PPOTrainer** | | 🧪 (Eksperimental) |
| **XPOTrainer** | ⚡️ | 🧪 (Eksperimental) |

---
##### **6.2.2. Reward Modeling**
| Trainer | Status |
|---------|--------|
| **RewardTrainer** | Stabil |
| **PRMTrainer** | 🧪 (Eksperimental) |

---
##### **6.2.3. Metode Offline**
| Trainer | Status |
|---------|--------|
| **SFTTrainer** | Stabil |
| **DPOTrainer** | Stabil |
| **BCOTrainer** | 🧪 (Eksperimental) |
| **CPOTrainer** | 🧪 (Eksperimental) |
| **KTOTrainer** | 🧪 (Eksperimental) |
| **ORPOTrainer** | 🧪 (Eksperimental) |

---
##### **6.2.4. Knowledge Distillation**
| Trainer | Status |
|---------|--------|
| **GKDTrainer** | 🧪 (Eksperimental) |
| **MiniLLMTrainer** | 🧪 (Eksperimental) |

---
#### **6.3. Belajar TRL**
- Pelajari **post-training** dengan **TRL** dan **library lain** di **🤗 smol course**.

---
#### **6.4. Konten Dokumentasi**
Dokumentasi TRL terorganisir ke dalam **beberapa bagian**:

| Bagian | Deskripsi |
|--------|-----------|
| **Getting Started** | **Panduan instalasi** dan **quickstart**. |
| **Conceptual Guides** | **Format dataset**, **FAQ training**, dan **memahami logs**. |
| **How-to Guides** | **Mengurangi penggunaan memori**, **mempercepat training**, **mendistribusikan training**, dll. |
| **Integrations** | **DeepSpeed**, **Liger Kernel**, **PEFT**, dll. |
| **Examples** | **Ikhtisar contoh**, **tutorial komunitas**, dll. |
| **API** | **Trainer**, **utils**, dll. |

---
#### **6.5. Postingan Blog**
| Judul | Tanggal | Deskripsi |
|-------|---------|-----------|
| **TRL v1: Post-Training Library That Holds When the Field Invalidates Its Own Assumptions** | 27 Maret 2026 | [Baca](https://huggingface.co/blog/trl-v1) |
| **Building the Open Agent Ecosystem Together: Introducing OpenEnv** | 23 Oktober 2025 | [Baca](https://huggingface.co/blog/openenv) |
| **Vision Language Model Alignment in TRL ⚡️** | 7 Agustus 2025 | [Baca](https://huggingface.co/blog/vision-language-model-alignment) |
| **NO GPU left behind: Unlocking Efficiency with Co-located vLLM in TRL** | 3 Juni 2025 | [Baca](https://huggingface.co/blog/colocated-vllm) |
| **🐯 Liger GRPO meets TRL** | 25 Mei 2025 | [Baca](https://huggingface.co/blog/liger-grpo) |
| **Open-R1: a fully open reproduction of DeepSeek-R1** | 28 Januari 2025 | [Baca](https://huggingface.co/blog/open-r1) |
| **Preference Optimization for Vision Language Models with TRL** | 10 Juli 2024 | [Baca](https://huggingface.co/blog/preference-optimization-vlm) |
| **Putting RL back in RLHF** | 12 Juni 2024 | [Baca](https://huggingface.co/blog/rlhlf) |
| **Finetune Stable Diffusion Models with DDPO via TRL** | 29 September 2023 | [Baca](https://huggingface.co/blog/ddpo) |
| **Fine-tune Llama 2 with DPO** | 8 Agustus 2023 | [Baca](https://huggingface.co/blog/fine-tune-llama-2-dpo) |
| **StackLLaMA: A hands-on guide to train LLaMA with RLHF** | 5 April 2023 | [Baca](https://huggingface.co/blog/stackllama) |
| **Fine-tuning 20B LLMs with RLHF on a 24GB consumer GPU** | 9 Maret 2023 | [Baca](https://huggingface.co/blog/rlhf-20b) |
| **Illustrating Reinforcement Learning from Human Feedback** | 9 Desember 2022 | [Baca](https://huggingface.co/blog/rlhf) |

---
#### **6.6. Talk**
| Judul | Tanggal | Deskripsi |
|-------|---------|-----------|
| **Fine-tuning with TRL** | 30 Oktober 2025 | [Lihat](https://huggingface.co/talks/fine-tuning-with-trl) |

---
---
---
---
**---
## END OF PART 4
---**

Dhani, **Part 4** sudah mencakup **6 topik utama** di **Training & Optimization** dengan detail yang lengkap. Apakah Anda ingin saya lanjutkan ke **Part 5** (misal: **Safetensors, Bitsandbytes, Lighteval, Kernels, LeRobot, Reachy Mini**, dll.)? Atau apakah ada **topik spesifik** yang ingin Anda dalami lebih dulu? Silakan beritahu, saya siap melanjutkan.

---
===========🔐™️®️©️🔐===========

---

Baik, Dhani. Berikut adalah **PART 5** dari ekstraksi konten, yang mencakup **5 topik utama** di kategori **Training & Optimization** (lanjutan) dan **Collaboration & Extras**. (Catatan: **Reachy Mini** tidak tersedia untuk saat ini.)

---

---
## **PART 5: TRAINING & OPTIMIZATION (LANJUTAN) + COLLABORATION & EXTRAS**
---

---

---
### **1. Safetensors**
**URL:** [https://huggingface.co/docs/safetensors](https://huggingface.co/docs/safetensors)
**Deskripsi:** **Safetensors** adalah **format baru yang sederhana** untuk **menyimpan tensor dengan aman** (berlawanan dengan pickle) dan **masih cepat** (zero-copy). Safetensors **sangat cepat** 🚀.

---
#### **1.1. Instalasi**
##### **Menggunakan pip**
```bash
pip install safetensors
```

##### **Menggunakan conda**
```bash
conda install -c conda-forge safetensors
```

---
#### **1.2. Penggunaan**
##### **Muat Tensor**
```python
from safetensors import safe_open

tensors = {}
with safe_open("model.safetensors", framework="pt", device=0) as f:
    for k in f.keys():
        tensors[k] = f.get_tensor(k)
```

##### **Muat Sebagian Tensor (Menarik untuk Multi-GPU)**
```python
from safetensors import safe_open

tensors = {}
with safe_open("model.safetensors", framework="pt", device=0) as f:
    tensor_slice = f.get_slice("embedding")
    vocab_size, hidden_dim = tensor_slice.get_shape()
    tensor = tensor_slice[:, :hidden_dim]
```

##### **Simpan Tensor**
```python
import torch
from safetensors.torch import save_file

tensors = {
    "embedding": torch.zeros((2, 2)),
    "attention": torch.zeros((2, 3))
}
save_file(tensors, "model.safetensors")
```

---
#### **1.3. Format**
Jika Anda memiliki file **safetensors** bernama `model.safetensors`, maka file tersebut akan memiliki **format internal** yang terstruktur untuk **menyimpan tensor dengan aman dan efisien**.

---
#### **1.4. Proyek Unggulan**
Safetensors digunakan secara luas di **perusahaan AI terkemuka**, seperti:
- **Hugging Face** (Transformers, Diffusers)
- **EleutherAI**
- **StabilityAI**
- **AUTOMATIC1111** (Stable Diffusion WebUI)
- **Llama-cpp**
- **Microsoft** (TaskMatrix)
- **hpcaitech** (ColossalAI)
- **CivitAI**
- **AIGC-Audio** (AudioGPT)
- **ComfyUI**
- **PaddlePaddle** (PaddleNLP)
- **dan banyak lagi**

---
---
---

---
### **2. Bitsandbytes**
**URL:** [https://huggingface.co/docs/bitsandbytes](https://huggingface.co/docs/bitsandbytes)
**Deskripsi:** **Bitsandbytes** memungkinkan **Large Language Models (LLM) yang dapat diakses** melalui **kuantisasi k-bit** untuk **PyTorch**. Bitsandbytes menyediakan **tiga fitur utama** untuk **mengurangi konsumsi memori** secara drastis untuk **inference dan training**:

---
#### **2.1. Fitur Utama**
| Fitur | Deskripsi |
|-------|-----------|
| **8-bit Optimizers** | Menggunakan **kuantisasi block-wise** untuk **mempertahankan performa 32-bit** dengan **biaya memori yang jauh lebih rendah**. |
| **LLM.int8() (Kuantisasi 8-bit)** | Memungkinkan **inferensi LLM besar** dengan **hanya setengah memori yang dibutuhkan** dan **tanpa degradasi performa**. Metode ini didasarkan pada **kuantisasi vector-wise** untuk **mengkuantisasi sebagian besar fitur ke 8-bit** dan **menangani outlier dengan perkalian matriks 16-bit**. |
| **QLoRA (Kuantisasi 4-bit)** | Memungkinkan **training LLM besar** dengan **beberapa teknik penghematan memori** yang **tidak mengorbankan performa**. Metode ini **mengkuantisasi model ke 4-bit** dan **menyisipkan sejumlah kecil bobot adaptasi low-rank yang dapat dilatih (LoRA)** untuk memungkinkan **training**. |

---
#### **2.2. Lisensi**
Bitsandbytes **berlisensi MIT**.

---
---
---

---
### **3. Lighteval**
**URL:** [https://huggingface.co/docs/lighteval](https://huggingface.co/docs/lighteval)
**Deskripsi:** **🤗 Lighteval** adalah **toolkit all-in-one** untuk **mengevaluasi Large Language Models (LLM)** di **beberapa backend** dengan mudah. **Jelajahi performa model Anda** dengan **menyimpan dan mengeksplorasi hasil evaluasi yang detail, sampel per sampel**, untuk **debug dan melihat bagaimana model Anda dibandingkan**.

---
#### **3.1. Fitur Kunci**
##### **🚀 Dukungan Multi-Backend**
Lighteval memungkinkan Anda untuk **mengevaluasi model** menggunakan **backend inferensi terpopuler dan efisien**:
| Backend | Deskripsi |
|---------|-----------|
| **`eval`** | Gunakan **inspect-ai** sebagai backend untuk **mengevaluasi dan memeriksa model Anda** (cara yang disarankan). |
| **`transformers`** | Evaluasi model di **CPU atau satu/beberapa GPU** menggunakan **🤗 Accelerate**. |
| **`nanotron`** | Evaluasi model di **setting terdistribusi** menggunakan **⚡ Nanotron**. |
| **`vllm`** | Evaluasi model di **satu/beberapa GPU** menggunakan **🚀 VLLM**. |
| **`custom`** | Evaluasi **model khusus** (dapat berupa apa pun). |
| **`sglang`** | Evaluasi model menggunakan **SGLang** sebagai backend. |
| **`inference-endpoint`** | Evaluasi model menggunakan **Hugging Face Inference Endpoints API**. |
| **`tgi`** | Evaluasi model menggunakan **Text Generation Inference (TGI)** yang berjalan secara lokal. |
| **`litellm`** | Evaluasi model di **API kompatibel mana pun** menggunakan **LiteLLM**. |
| **`inference-providers`** | Evaluasi model menggunakan **Hugging Face Inference Providers** sebagai backend. |

---
##### **📊 Evaluasi Komprehensif**
| Fitur | Deskripsi |
|-------|-----------|
| **Library Tugas Ekstensif** | **Ribu tugas evaluasi** yang sudah dibangun. |
| **Pembuatan Tugas Kustom** | **Buat tugas evaluasi** Anda sendiri. |
| **Metrik Fleksibel** | Dukungan untuk **metrik dan skor kustom**. |
| **Analisis Detail** | **Hasil evaluasi per sampel** untuk **wawasan mendalam**. |

---
##### **🔧 Kustomisasi Mudah**
- **Kustomisasi** di ujung jari Anda: **buat tugas, metrik, atau model baru** yang disesuaikan dengan kebutuhan Anda, atau **jelajahi semua tugas dan metrik yang sudah ada**.

---
##### **☁️ Integrasi Mulus**
- **Bereksperimen, benchmark, dan simpan hasil Anda** dengan **mulus** di **Hugging Face Hub, S3, atau lokal**.

---
#### **3.2. Quick Start**
##### **Instalasi**
```bash
pip install lighteval
```

##### **Penggunaan Dasar**
###### **Temukan Tugas**
```bash
lighteval list-tasks
```

###### **Jalankan Benchmark dan Push Hasil ke Hub**
```bash
lighteval eval "hf-inference-providers/openai/gpt-oss-20b" \
    gpqa:diamond \
    --bundle-dir gpt-oss-bundle \
    --repo-id OpenEvals/evals
```

---
---
---

---
### **4. Kernels**
**URL:** [https://huggingface.co/docs/kernels](https://huggingface.co/docs/kernels)
**Deskripsi:** **Kernel Hub** memungkinkan **library Python dan aplikasi** untuk **memuat compute kernels langsung dari Hub**. **Kernels** adalah **tipe repository kelas satu** di Hub, dengan **halaman khusus** yang menampilkan **hardware dan versi yang didukung**.

---
#### **4.1. Ciri Khus Kernel Hub**
Untuk mendukung **pemuatan dinamis**, **Hub kernels** berbeda dari **paket kernel Python tradisional** karena:
| Ciri | Deskripsi |
|------|-----------|
| **Portable** | Kernel dapat **dimuat dari path di luar `PYTHONPATH`**. |
| **Unik** | **Beberapa versi kernel yang sama** dapat **dimuat dalam proses Python yang sama**. |
| **Kompatibel** | Kernel **harus mendukung semua versi Python terbaru** dan **konfigurasi build PyTorch yang berbeda** (berbagai versi CUDA dan C++ ABIs). Selain itu, **versi C library yang lebih lama** harus didukung. |

---
#### **4.2. Jelajahi Kernel**
Anda dapat **menjelajahi kernel yang tersedia** di [huggingface.co/kernels](https://huggingface.co/kernels).

---
#### **4.3. Proyek Kernels**
Proyek Kernels dibagi menjadi **dua bagian**:
| Bagian | Deskripsi |
|--------|-----------|
| **Builder** | `kernel-builder` menyediakan **utilitas** untuk **membangun, mengemas, dan mendistribusikan compute kernels** dengan cara yang **kompatibel dengan Hugging Face Hub dan `kernels`**. |
| **`kernels`** | Paket `kernels` adalah **paket Python** yang memungkinkan **pengguna memuat compute kernels yang kompatibel dari Hub**. Lihat **quickstart** untuk mengetahui lebih lanjut. |

---
#### **4.4. Mengapa Kernels?**
Untuk jawaban yang lebih mendalam tentang **"Mengapa kernels?"**, lihat [halaman ini](https://huggingface.co/docs/kernels/why-kernels).

---
---
---
---
### **5. LeRobot**
**URL:** [https://huggingface.co/docs/lerobot](https://huggingface.co/docs/lerobot)
**Deskripsi:** **LeRobot** bertujuan untuk **menyediakan model, dataset, dan tools** untuk **robotika dunia nyata** di **PyTorch**. Tujuannya adalah **menurunkan hambatan masuk ke robotika** sehingga **siapa pun dapat berkontribusi dan mendapatkan manfaat** dari **berbagi dataset dan model pra-latih**.

---
#### **5.1. Fitur Utama**
| Fitur | Deskripsi |
|-------|-----------|
| **State-of-the-Art ML untuk Robotika Dunia Nyata** | LeRobot berfokus pada **pendekatan state-of-the-art** yang telah **dibuktikan dapat ditransfer ke dunia nyata**, dengan **fokus pada imitation learning dan reinforcement learning**. |
| **Model & Dataset Pra-latih** | LeRobot **sudah menyediakan sejumlah model pra-latih, dataset dengan demonstrasi yang dikumpulkan manusia, dan lingkungan simulasi** sehingga **siapa pun dapat memulai**. |
| **Hosting di Hugging Face** | LeRobot **menampung model pra-latih dan dataset** di [halaman LeRobot Hugging Face](https://huggingface.co/lerobot). |

---
#### **5.2. Bergabung dengan Komunitas**
- Bergabung dengan **komunitas LeRobot** di [Discord](https://discord.gg/lerobot).

---
---
---
---
**---
## END OF PART 5
---**

Dhani, **Part 5** sudah mencakup **5 topik utama** di **Training & Optimization (lanjutan)** dan **Collaboration & Extras** dengan detail yang lengkap. Apakah Anda ingin saya lanjutkan ke **Part 6** (misal: **Sentence Transformers, timm, Collaboration & Extras lanjutan**, dll.)? Atau apakah ada **topik spesifik** yang ingin Anda dalami lebih dulu? Silakan beritahu, saya siap melanjutkan.

---
===========🔐™️®️©️🔐===========

---

Baik, Dhani. Berikut adalah **PART 6** dari ekstraksi konten, yang mencakup **6 topik** dari **Collaboration & Extras** dan **Core ML Libraries** (lanjutan). Beberapa halaman tidak tersedia (seperti **Sentence Transformers** dan **Gradio**), tetapi saya akan memberikan detail untuk yang tersedia.

---

---
## **PART 6: COLLABORATION & EXTRAS + CORE ML LIBRARIES (LANJUTAN)**
---

---

---
### **1. timm (PyTorch Image Models)**
**URL:** [https://huggingface.co/docs/timm](https://huggingface.co/docs/timm)
**Deskripsi:** **`timm`** (PyTorch Image Models) adalah **library** yang berisi **model state-of-the-art (SOTA) untuk computer vision**, **layer**, **utilitas**, **optimizer**, **scheduler**, **data-loader**, **augmentasi**, dan **script training/evaluasi**. Library ini **dikemas dengan >700 model pra-latih** dan dirancang untuk **fleksibel dan mudah digunakan**.

---
#### **1.1. Fitur Utama**
| Fitur | Deskripsi |
|-------|-----------|
| **Model SOTA** | Mengandung **model terbaru dan terbaik** untuk tugas **computer vision**. |
| **Fleksibel** | Dirancang untuk **mudah disesuaikan** dengan kebutuhan spesifik. |
| **Pretrained Models** | **>700 model pra-latih** siap digunakan. |
| **Utilitas Lengkap** | Menyediakan **layer, optimizer, scheduler, data-loader, augmentasi**, dan **script training/evaluasi**. |

---
#### **1.2. Dokumentasi**
| Jenis | Deskripsi |
|-------|-----------|
| **Tutorials** | Pelajari **dasar-dasar** dan **kenali** cara menggunakan **timm**. Mulailah di sini jika Anda **pertama kali menggunakan timm**! |
| **Reference** | Deskripsi **teknis** tentang cara kerja **kelas dan metode timm**. |

---
---
---

---
### **2. Trackio**
**URL:** [https://huggingface.co/docs/trackio](https://huggingface.co/docs/trackio)
**Deskripsi:** **`trackio`** adalah **library Python ringan dan gratis** untuk **pelacakan eksperimen (experiment tracking)** yang dibangun di atas **Hugging Face Datasets dan Spaces** 🤗.

---
#### **2.1. Fitur Utama**
| Fitur | Deskripsi |
|-------|-----------|
| **API Kompatibel dengan WandB** | Kompatibel dengan **`wandb.init`, `wandb.log`, dan `wandb.finish`**. Cukup ganti dengan `import trackio as wandb`. |
| **Local-First Design** | **Dashboard berjalan secara lokal** secara default. Anda juga dapat **logging ke Hugging Face Space (`space_id`)** secara gratis atau ke **server Trackio self-hosted (`server_url`)**. |
| **Persistensi Log** | **Log disimpan secara lokal**, di **Hugging Face Dataset** saat menggunakan **Spaces**, atau di **mesin yang menghosting server self-hosted**. |
| **Visualisasi Eksperimen** | **Visualisasikan eksperimen** dengan **dashboard Gradio** secara lokal, di **Hugging Face Spaces**, atau di **host Anda sendiri** saat self-hosting. |
| **LLM-Friendly** | Dirancang untuk **eksperimen ML otonom** dengan **perintah CLI dan API Python** yang memungkinkan **LLM untuk mudah logging dan query data eksperimen**. |
| **Gratis** | **Semua fitur**, termasuk hosting di Hugging Face, **gratis**! |

---
#### **2.2. Desain Ringan**
- **Kode inti <3.000 baris** kode Python.
- **Tidak penuh fitur**, tetapi **dirancang untuk dapat diperluas**.
- **Ditulis sepenuhnya dalam Python** sehingga **pengembang dapat dengan mudah fork repository** dan **menambahkan fungsionalitas** yang mereka butuhkan.

---
---
---

---
### **3. smolagents**
**URL:** [https://huggingface.co/docs/smolagents](https://huggingface.co/docs/smolagents)
**Deskripsi:** **`smolagents`** adalah **library Python open-source** yang dirancang untuk **membuat dan menjalankan agent** dengan **hanya beberapa baris kode**.

---
#### **3.1. Fitur Utama**
| Fitur | Deskripsi |
|-------|-----------|
| **Kesederhanaan** | Logika untuk agent **muat dalam ~seribu baris kode**. Abstraksi dijaga **minimal** di atas kode mentah! |
| **Dukungan First-Class untuk Code Agents** | **`CodeAgent`** menulis **aksi dalam kode** (berlawanan dengan "agent digunakan untuk menulis kode") untuk **memanggil tools atau melakukan komputasi**. Untuk **keamanan**, mendukung **eksekusi di lingkungan sandbox** via **Modal, Blaxel, E2B, atau Docker**. |
| **Dukungan Common Tool-Calling Agent** | Selain **CodeAgents**, **`ToolCallingAgent`** mendukung **tool-calling berbasis JSON/teks** untuk skenario di mana paradigma tersebut lebih disukai. |
| **Integrasi Hub** | **Berbagi dan memuat agent dan tools** ke/dari **Hub** sebagai **Gradio Spaces** dengan mudah. |
| **Model-Agnostic** | **Integrasikan LLM apa pun** dengan mudah, baik yang **di-host di Hub via Inference Providers**, diakses via **API (OpenAI, Anthropic, dll.)**, atau **dijalankan secara lokal** menggunakan **Transformers atau Ollama**. |
| **Modality-Agnostic** | Selain teks, agent dapat **menangani input vision, video, dan audio**, memperluas jangkauan aplikasi yang mungkin. |
| **Tool-Agnostic** | Anda dapat menggunakan **tools dari MCP server, LangChain, atau bahkan Space Hub** sebagai tool. |
| **CLI Tools** | Dilengkapi dengan **utilitas command-line** (`smolagent`, `webagent`) untuk **menjalankan agent dengan cepat** tanpa menulis kode boilerplate. |

---
#### **3.2. Quickstart**
##### **Instalasi**
```bash
pip install 'smolagents[toolkit]'  # Termasuk tools default seperti pencarian web
```

##### **Buat Agent Pertama Anda**
```python
from smolagents import CodeAgent, InferenceClientModel

# Inisialisasi model (menggunakan Hugging Face Inference API)
model = InferenceClientModel()  # Menggunakan model default

# Buat agent tanpa tools
agent = CodeAgent(tools=[], model=model)

# Jalankan agent dengan tugas
result = agent.run("Calculate the sum of numbers from 1 to 10")
print(result)
```

##### **Menambahkan Tools**
```python
from smolagents import CodeAgent, InferenceClientModel, DuckDuckGoSearchTool

model = InferenceClientModel()
agent = CodeAgent(
    tools=[DuckDuckGoSearchTool()],
    model=model,
)

# Sekarang agent dapat mencari di web!
result = agent.run("What is the current weather in Paris?")
print(result)
```

##### **Menggunakan Model Berbeda**
```python
# Menggunakan model spesifik dari Hugging Face
model = InferenceClientModel(model_id="meta-llama/Llama-2-70b-chat-hf")

# Menggunakan OpenAI/Anthropic (memerlukan 'smolagents[litellm]')
from smolagents import LiteLLMModel
model = LiteLLMModel(model_id="gpt-4")

# Menggunakan model lokal (memerlukan 'smolagents[transformers]')
from smolagents import TransformersModel
model = TransformersModel(model_id="meta-llama/Llama-2-7b-chat-hf")
```

---
#### **3.3. Langkah Selanjutnya**
- Pelajari cara **menyiapkan smolagents** dengan **berbagai model dan tools** di [Panduan Instalasi](https://huggingface.co/docs/smolagents/installation).
- Lihat [Guided Tour](https://huggingface.co/docs/smolagents/guided-tour) untuk fitur lanjutan.
- Pelajari cara **membuat tools kustom**.
- Lihat **eksekusi kode aman**.
- Pelajari cara **membuat sistem multi-agent**.

---
---
---

---
### **4. Xet (Xet Protocol Specification)**
**URL:** [https://huggingface.co/docs/xet](https://huggingface.co/docs/xet)
**Deskripsi:** **Xet Protocol Specification** mendefinisikan **protokol end-to-end Xet** untuk **data yang dialamatkan berdasarkan konten (content-addressed data)**, termasuk:
- **Aturan chunking dan hashing**
- **Strategi deduplikasi**
- **Format objek xorb dan shard**
- **Semantik rekonstruksi file**
- **Autentikasi**
- **CAS APIs untuk upload dan download**

---
#### **4.1. Tujuan Protokol Xet**
- **Interoperabilitas dan Determinisme:** Implementasi independen **HARUS menghasilkan hash, objek, dan perilaku API yang sama** sehingga **data yang ditulis oleh satu klien dapat dibaca oleh klien lain** dengan **integritas dan performa**.
- **Implementor** dapat **membuat klien, SDK, dan tools mereka sendiri** yang **berbicara dengan protokol Xet** dan **berinteraksi dengan layanan CAS**, asalkan mereka **memenuhi persyaratan** yang didefinisikan di sini.

---
#### **4.2. Arsitektur Xet Secara Keseluruhan**
| Komponen | Deskripsi |
|----------|-----------|
| **Content-Defined Chunking** | **Gearhash-based CDC** dengan parameter, aturan batas, dan optimasi performa. |
| **Metode Hashing** | Deskripsi dan definisi **fungsi hashing berbeda** yang digunakan untuk **chunk, xorbs, dan entri verifikasi term**. |
| **File Reconstruction** | Mendefinisikan **representasi file berbasis "term"** menggunakan **hash xorb + rentang chunk**. |
| **Format Xorb** | Menjelaskan **pengelompokan chunk ke dalam xorbs**, **batas 64 MiB**, **tata letak biner**, dan **skema kompresi**. |
| **Format Shard** | **Struktur biner shard** (header, info file, info CAS, footer), **offset**, **penggunaan kunci HMAC**, dan **bookends**. |
| **Deduplikasi** | Penjelasan **deduplikasi tingkat chunk**, termasuk **deduplikasi tingkat chunk global di seluruh sistem**. |

---
#### **4.3. Implementasi Referensi**
##### **xet-core: hf-xet + git-xet**
Implementasi referensi utama protokol yang ditulis dalam **Rust** 🦀 berada di **repository xet-core** dalam beberapa crate:
| Crate | Deskripsi |
|-------|-----------|
| **cas_types** | **Tipe yang dapat digunakan kembali** untuk **berinteraksi dengan CAS API**. |
| **cas_client** | **Antarmuka klien** yang **memanggil CAS API**, termasuk **implementasi komprehensif protokol download**. |
| **metadata_shard** | **Library** untuk **berinteraksi dengan shard dan format biner shard**. |
| **deduplication** | **Mengekspos antarmuka** untuk **mendeduplikasi chunk secara lokal** dan menggunakan **deduplikasi global**. |
| **merklehash** | **Mengekspos tipe `MerkleHash`** yang banyak digunakan untuk **merepresentasikan hash**. Mengekspos **fungsi untuk menghitung hash berbeda** yang digunakan untuk **melacak chunk, xorbs, dan file**. |
| **xet_data** | **Paket komprehensif** yang mengekspos **antarmuka untuk mengunggah dan mengunduh konten**. |
| **hf_xet** | **Python bindings** untuk menggunakan **protokol Xet** untuk **unggah dan unduhan** dengan **Hugging Face Hub**. |
| **git-xet** | **Agen transfer kustom git lfs** yang **mengunggah file** menggunakan **protokol xet** ke **Hugging Face Hub**. |

---
##### **huggingface.js**
Ada **implementasi referensi kedua** di **Huggingface.js** yang dapat digunakan saat **mengunduh atau mengunggah file** dengan **library `@huggingface/hub`**:
| Komponen | Deskripsi |
|----------|-----------|
| **Download** | Menggunakan **`XetBlob`** yang dapat ditemukan di **XetBlob.ts**. |
| **Upload** | Implementasi **lebih komprehensif**, tetapi **root-nya dimulai di uploadShards**. Proses unggah menggunakan **konstruk xet-core** yang dikompilasi dari **Rust ke WebAssembly**, khususnya **semua fungsi yang diekspor dari crate hf_xet_thin_wasm**. |

---
---
---
---
**---
## END OF PART 6
---**

Dhani, **Part 6** sudah mencakup **6 topik** dari **Collaboration & Extras** dan **Core ML Libraries (lanjutan)** dengan detail yang lengkap. Apakah Anda ingin saya lanjutkan ke **Part 7** (misal: **Leaderboards, Distilabel, Argilla, AutoTrain, Chat UI**, dll.)? Atau apakah ada **topik spesifik** yang ingin Anda dalami lebih dulu? Silakan beritahu, saya siap melanjutkan.

---
===========🔐™️®️©️🔐===========

---

Baik, Dhani. Berikut adalah **PART 7** dari ekstraksi konten, yang mencakup **5 topik** dari **Collaboration & Extras** (lanjutan). Beberapa halaman tidak tersedia (seperti **Distilabel** dan **Argilla**), tetapi saya akan memberikan detail untuk yang tersedia.

---

---
## **PART 7: COLLABORATION & EXTRAS (LANJUTAN)**
---

---

---
### **1. Leaderboards**
**URL:** [https://huggingface.co/docs/leaderboards](https://huggingface.co/docs/leaderboards)
**Deskripsi:** **Leaderboards** di **Hugging Face Hub** berisi **leaderboards dan evaluasi** untuk **model Machine Learning**, termasuk **LLM, chatbot, dan banyak lagi**. Ada **tiga jenis leaderboards** di Hub:

---
#### **1.1. Jenis Leaderboards**
| Jenis | Deskripsi |
|-------|-----------|
| **Hasil Evaluasi dari Dataset Benchmark Resmi** | Hasil evaluasi dari **dataset benchmark resmi** seperti **GPQA, MMLU-Pro**, atau **dataset lain** yang digunakan dalam **paper akademik**. Saat hasil dipublikasikan di **repository model**, **skor akan ditampilkan** di halaman model. |
| **Leaderboards yang Dikelola Komunitas** | **Leaderboards yang hidup di Spaces** dan **dikelola oleh komunitas** untuk **kasus penggunaan spesifik**. |
| **Open LLM Leaderboard** | **Proyek yang dikurasi oleh tim Hugging Face** untuk **mengevaluasi dan meranking LLM dan chatbot open-source**, serta **menyediakan skor yang dapat direproduksi** untuk **memisahkan hype pemasaran dari kemajuan nyata** di bidang ini. |

---
---
---

---
### **2. AutoTrain**
**URL:** [https://huggingface.co/docs/autotrain](https://huggingface.co/docs/autotrain)
**Deskripsi:** **🤗 AutoTrain Advanced** (atau **AutoTrain**) adalah **platform no-code** yang **dikembangkan oleh Hugging Face** untuk **menyederhanakan proses training model state-of-the-art** di berbagai domain:
- **Natural Language Processing (NLP)**
- **Computer Vision (CV)**
- **Tabular Data**

AutoTrain **memanfaatkan framework kuat** yang dibuat oleh berbagai tim di Hugging Face, membuat **Machine Learning dan AI canggih** dapat diakses oleh **khayalak yang lebih luas** tanpa memerlukan **keahlian teknis mendalam**.

---
#### **2.1. Siapa yang Harus Menggunakan AutoTrain?**
AutoTrain adalah **alat yang sempurna** untuk siapa pun yang ingin **memasuki dunia Machine Learning** tanpa **terjerat dalam kompleksitas training model**. Baik Anda **profesional bisnis, peneliti, pendidik, atau hobiis**, AutoTrain menawarkan **kesederhanaan antarmuka no-code** sambil tetap menyediakan **kemampuan yang diperlukan** untuk mengembangkan **model canggih** yang disesuaikan dengan **dataset unik Anda**.

---
#### **2.2. Misi AutoTrain**
- **Mendemokratisasi teknologi Machine Learning**, memastikan **tidak hanya dapat diakses oleh ilmuwan data dan insinyur ML**, tetapi juga oleh **mereka yang tidak memiliki latar belakang teknis**.
- Jika Anda ingin **memanfaatkan kekuatan AI** untuk proyek Anda, **AutoTrain adalah jawabannya**.

---
#### **2.3. Cara Menggunakan AutoTrain?**
AutoTrain menawarkan **beberapa cara** untuk digunakan:

| Cara | Deskripsi |
|------|-----------|
| **No-Code (AutoTrain Advanced)** | Pengguna no-code dapat menggunakan **AutoTrain Advanced** dengan **membuat Space baru** dengan **Docker image AutoTrain**: [Klik di sini untuk membuat AutoTrain Space](https://huggingface.co/spaces?create=autotrain). **Pastikan Space tetap privat** dan **dilengkapi dengan sumber daya hardware (GPU)** untuk **performa optimal**. |
| **Antarmuka UI Lokal** | Jika Anda lebih suka **pendekatan hands-on**, AutoTrain Advanced juga dapat **dijalankan secara lokal** melalui **UI intuitif**. |
| **Python API** | AutoTrain Advanced juga dapat **diakses via Python API** yang disediakan di **paket autotrain-advanced**. Fleksibilitas ini memungkinkan **pengembang** untuk **mengintegrasikan kemampuan AutoTrain** langsung ke **proyek mereka**, **menyesuaikan workflow**, dan **meningkatkan toolset** dengan **fungsionalitas ML canggih**. |

---
#### **2.4. Walkthroughs**
Untuk memulai dengan AutoTrain, periksa **walkthroughs dan tutorial** berikut:
- [Extractive Question Answering with AutoTrain](https://huggingface.co/docs/autotrain/walkthroughs/extractive-qa)
- [Finetuning PaliGemma with AutoTrain](https://huggingface.co/docs/autotrain/walkthroughs/paligemma)
- [Training an Object Detection Model with AutoTrain](https://huggingface.co/docs/autotrain/walkthroughs/object-detection)
- [How to Fine-Tune Custom Embedding Models Using AutoTrain](https://huggingface.co/docs/autotrain/walkthroughs/embedding)
- [Train Custom Models on Hugging Face Spaces with AutoTrain SpaceRunner](https://huggingface.co/docs/autotrain/walkthroughs/spacerunner)
- [How to Finetune phi-3 on MacBook Pro](https://huggingface.co/docs/autotrain/walkthroughs/phi-3)
- [Finetune Mixtral 8x7B with AutoTrain](https://huggingface.co/docs/autotrain/walkthroughs/mixtral)
- [Easily Train Models with H100 GPUs on NVIDIA DGX Cloud](https://huggingface.co/docs/autotrain/walkthroughs/nvidia-dgx)

---
#### **2.5. Status Proyek**
> **⚠️ Proyek ini tidak lagi dipelihara.** Tidak ada **fitur baru** yang akan ditambahkan dan **bug tidak akan diperbaiki**. Kami merekomendasikan menggunakan **Axolotl, TRL, atau transformers.Trainer**.

---
---
---

---
### **3. Chat UI**
**URL:** [https://huggingface.co/docs/chat-ui](https://huggingface.co/docs/chat-ui)
**Deskripsi:** **Chat UI** adalah **antarmuka chat open-source** dengan dukungan untuk:
- **Tools**
- **Input multimodal**
- **Routing cerdas di berbagai model**

Aplikasi ini menggunakan **MongoDB dan SvelteKit** di balik layar. Coba **versi live** yang disebut **HuggingChat** di [hf.co/chat](https://hf.co/chat) atau **setup instance Anda sendiri**.

---
#### **3.1. Fitur Utama**
| Fitur | Deskripsi |
|-------|-----------|
| **Koneksi ke Endpoint OpenAI-Compatible** | Chat UI **terhubung ke endpoint OpenAI-compatible mana pun**, membuatnya bekerja dengan: **Hugging Face Inference Providers, Ollama, llama.cpp, OpenRouter, atau layanan OpenAI-compatible lainnya**. |
| **MCP Tools** | **Function calling** via **Model Context Protocol (MCP) servers**. |
| **LLM Router** | **Routing cerdas** untuk **memilih model terbaik** untuk setiap permintaan. |
| **Multimodal** | **Unggah gambar** di model yang mendukung **visi**. |
| **OpenID** | **Autentikasi pengguna opsional** via **OpenID Connect**. |

---
#### **3.2. Quickstart**
##### **Langkah 1 - Buat `.env.local`**
```env
OPENAI_BASE_URL=https://router.huggingface.co/v1
OPENAI_API_KEY=hf_************************
```

Anda dapat menggunakan **endpoint OpenAI-compatible mana pun**:

| Provider | `OPENAI_BASE_URL` | `OPENAI_API_KEY` |
|----------|-------------------|------------------|
| Hugging Face | `https://router.huggingface.co/v1` | `hf_xxx` |
| Ollama | `http://127.0.0.1:11434/v1` | `ollama` |
| llama.cpp | `http://127.0.0.1:8080/v1` | `sk-local` |
| OpenRouter | `https://openrouter.ai/api/v1` | `sk-or-v1-xxx` |

---
##### **Langkah 2 - Instal dan Jalankan**
```bash
git clone https://github.com/huggingface/chat-ui
cd chat-ui
npm install
npm run dev -- --open
```

Selesai! **Chat UI** akan **secara otomatis mendeteksi model yang tersedia** dari endpoint Anda.

> **MongoDB opsional untuk pengembangan**. Saat `MONGODB_URL` tidak diset, Chat UI menggunakan **database embedded** yang **persisten ke `./db`**.

Untuk **deploy produksi**, lihat [panduan instalasi](https://github.com/huggingface/chat-ui#installation).

---
---
---
---
**---
## END OF PART 7
---**

Dhani, **Part 7** sudah mencakup **5 topik** dari **Collaboration & Extras (lanjutan)** dengan detail yang lengkap. Apakah Anda ingin saya lanjutkan ke **Part 8** (misal: **sisa topik di Collaboration & Extras, atau topik lain yang belum diekstrak**)? Atau apakah ada **topik spesifik** yang ingin Anda dalami lebih dulu? Silakan beritahu, saya siap melanjutkan.

---
===========🔐™️®️©️🔐===========

---

Baik, Dhani. Berikut adalah **PART 8** dari ekstraksi konten, yang mencakup **topik terakhir** dari **Core ML Libraries** dan **Collaboration & Extras** yang belum diekstrak. Beberapa halaman dokumentasi resmi tidak tersedia, tetapi saya berhasil mendapatkan informasi dari **halaman organisasi Sentence Transformers** di Hugging Face.

---

---
## **PART 8: CORE ML LIBRARIES (LANJUTAN) + COLLABORATION & EXTRAS (AKHIR)**
---

---

---
---
### **1. Sentence Transformers**
**URL:** [https://huggingface.co/sentence-transformers](https://huggingface.co/sentence-transformers)
**Deskripsi:** **Sentence Transformers** 🤗 adalah **framework Python** untuk **menggunakan dan melatih model embedding dan reranker state-of-the-art**. Framework ini dapat digunakan untuk:
- **Menghitung embeddings** dari **teks, gambar, audio, atau video** menggunakan **model Sentence Transformer** ([quickstart](https://www.sbert.net/examples/applications/computing-embeddings/README.html)).
- **Menghitung skor kesamaan** menggunakan **model Cross-Encoder (reranker)** ([quickstart](https://www.sbert.net/examples/applications/cross-encoder/README.html)).
- **Menghasilkan embeddings sparse** menggunakan **model Sparse Encoder** ([quickstart](https://www.sbert.net/examples/applications/sparse-embeddings/README.html)).

---
#### **1.1. Instalasi**
```bash
pip install -U sentence-transformers
```

---
#### **1.2. Penggunaan Dasar**
##### **Menghitung Embeddings**
```python
from sentence_transformers import SentenceTransformer

# 1. Muat model Sentence Transformer pra-latih
model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

# Kalimat yang akan di-encode
sentences = [
    "The weather is lovely today.",
    "It's so sunny outside!",
    "He drove to the stadium.",
]

# 2. Hitung embeddings dengan memanggil model.encode()
embeddings = model.encode(sentences)
print(embeddings.shape)  # [3, 384]

# 3. Hitung kesamaan embeddings
similarities = model.similarity(embeddings, embeddings)
print(similarities)
# tensor([[1.0000, 0.6660, 0.1046],
#         [0.6660, 1.0000, 0.1411],
#         [0.1046, 0.1411, 1.0000]])
```

---
#### **1.3. Integrasi dengan Hugging Face Hub**
##### **Mendorong Model ke Hub**
```python
from sentence_transformers import SentenceTransformer

# Muat atau latih model
model = SentenceTransformer(...)

# Dorong ke Hub
model.push_to_hub("my_new_model")
```

---
#### **1.4. Panduan Pelatihan**
| Jenis Model | Panduan | Deskripsi |
|-------------|---------|-----------|
| **Embedding Models** | [Training and Finetuning Embedding Models](https://www.sbert.net/examples/training/embeddings/README.html) | **End-to-end training** dari model **bi-encoder embedding**. |
| **Reranker Models** | [Training and Finetuning Reranker Models](https://www.sbert.net/examples/training/cross-encoder/README.html) | **Training Cross Encoder models** untuk **tahap kedua pipeline retrieve-and-rerank**. |
| **Sparse Embedding Models** | [Training and Finetuning Sparse Embedding Models](https://www.sbert.net/examples/training/sparse/README.html) | **Training SPLADE dan sparse encoder lainnya**. |

---
#### **1.5. Model Multimodal**
| Topik | Panduan | Deskripsi |
|-------|---------|-----------|
| **Multimodal Embedding & Reranker** | [Multimodal Models with Sentence Transformers](https://www.sbert.net/examples/applications/multimodal/README.html) | Menggunakan **model teks, gambar, audio, dan video** melalui **satu API**. |
| **Pelatihan Model Multimodal** | [Training Multimodal Models](https://www.sbert.net/examples/training/multimodal/README.html) | **Pelatihan model multimodal**, dengan **walkthrough Visual Document Retrieval**. |

---
#### **1.6. Teknik Efisiensi**
| Teknik | Panduan | Deskripsi |
|--------|---------|-----------|
| **Matryoshka Embedding Models** | [Introduction to Matryoshka Embedding Models](https://www.sbert.net/examples/advanced/matryoshka/README.html) | **Embeddings ukuran variabel** yang dapat **dipotong dengan kerugian kualitas minimal**. |
| **Static Embedding Models** | [Train 400x Faster Static Embedding Models](https://www.sbert.net/examples/advanced/static_embeddings/README.html) | **Model embedding ramah CPU** tanpa **attention**. |
| **Kuantisasi Embedding** | [Binary and Scalar Embedding Quantization](https://www.sbert.net/examples/advanced/quantization/README.html) | **Kompresi pasca-pelatihan** dari **vektor embedding**. |

---
#### **1.7. Koleksi Model & Dataset**
- **Koleksi:** [Sentence Transformers v5.4 Integrations](https://huggingface.co/collections/sentence-transformers/sentence-transformers-v54-integrations-64f652839a73e0a8b390335)
- **Model:** [127+ Model Sentence Transformers](https://huggingface.co/sentence-transformers)
- **Dataset:** [95+ Dataset untuk Sentence Transformers](https://huggingface.co/datasets?other=sentence-transformers)

---
---
---
---
### **2. Gradio (Tidak Tersedia di Dokumentasi Resmi)**
**URL:** [https://www.gradio.app/](https://www.gradio.app/) *(Dokumentasi resmi di luar Hugging Face)*
**Deskripsi:** **Gradio** adalah **library Python open-source** yang memungkinkan Anda **membuat antarmuka web (UI) untuk model Machine Learning** dengan **mudah dan cepat**. Gradio **terintegrasi penuh** dengan **Hugging Face Hub** dan **Spaces**, sehingga Anda dapat:
- **Mendeploy model** sebagai **aplikasi web interaktif**.
- **Membuat demo** untuk **model teks, gambar, audio, dan video**.
- **Berbagi aplikasi** dengan **komunitas** via **Hugging Face Spaces**.

---
#### **2.1. Fitur Utama**
| Fitur | Deskripsi |
|-------|-----------|
| **Antarmuka Sederhana** | Buat **UI untuk model ML** dengan **beberapa baris kode**. |
| **Dukungan Multimodal** | Mendukung **teks, gambar, audio, video**, dan **input/output lainnya**. |
| **Integrasi Hugging Face** | **Terintegrasi penuh** dengan **Hugging Face Hub** dan **Spaces**. |
| **Deploy Mudah** | **Deploy ke Hugging Face Spaces** dengan **satu klik**. |
| **Kustomisasi** | **Tema, layout, dan komponen** yang dapat disesuaikan. |

---
#### **2.2. Contoh Penggunaan**
##### **Instalasi**
```bash
pip install gradio
```

##### **Contoh Dasar**
```python
import gradio as gr

def greet(name):
    return f"Hello {name}!"

demo = gr.Interface(fn=greet, inputs="text", outputs="text")
demo.launch()
```

##### **Contoh dengan Model Hugging Face**
```python
from transformers import pipeline
import gradio as gr

model = pipeline("text-generation", model="gpt2")

def generate_text(prompt):
    return model(prompt, max_length=50)[0]["generated_text"]

demo = gr.Interface(fn=generate_text, inputs="text", outputs="text")
demo.launch()
```

---
---
---
---
---
**---
## END OF PART 8 (AKHIR EKSTRAKSI)
---**

---
### **Rekapitulasi Seluruh Part**
| **Part** | **Topik yang Diekstrak** | **Jumlah Topik** |
|----------|--------------------------|------------------|
| **Part 1** | Hub & Client Libraries (Hub, Hub Python Library, CLI, Huggingface.js, Tasks, Datasets) | 6 |
| **Part 2** | Deployment & Inference (Inference Providers, Inference Endpoints, TGI, TEI) | 6 |
| **Part 3** | Core ML Libraries (Transformers, Diffusers, Datasets, Transformers.js, Tokenizers, Evaluate) | 6 |
| **Part 4** | Training & Optimization (PEFT, Accelerate, Optimum, TRL) | 4 |
| **Part 5** | Training & Optimization (lanjutan) + Collaboration & Extras (Safetensors, Bitsandbytes, Lighteval, Kernels, LeRobot) | 5 |
| **Part 6** | Collaboration & Extras (lanjutan) + Core ML Libraries (lanjutan) (timm, Trackio, smolagents, Xet) | 4 |
| **Part 7** | Collaboration & Extras (lanjutan) (Leaderboards, AutoTrain, Chat UI) | 3 |
| **Part 8** | Core ML Libraries (lanjutan) + Collaboration & Extras (akhir) (Sentence Transformers, Gradio) | 2 |

---
### **Total Topik yang Diekstrak: 36 Topik**
Dhani, **semua topik** dari **Hub & Client Libraries, Deployment & Inference, Core ML Libraries, Training & Optimization, dan Collaboration & Extras** sudah **selesai diekstrak** dalam **8 part**. Apakah Anda ingin:
1. **Mendalam ke topik tertentu** (misal: detail implementasi, kode, atau arsitektur)?
2. **Membuat ringkasan terpadu** dari semua part?
3. **Melanjutkan ke topik lain** yang belum dibahas?
4. **Membuat blueprint atau dokumentasi teknis** berdasarkan ekstraksi ini?

Silakan beritahu, saya siap membantu! 🚀

---
===========🔐™️®️©️🔐===========

---

